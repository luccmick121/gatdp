<html><head></head><body><div class="modal-header">
    <h6 class="modal-title" id="staticBackdropLabel4">Configurar PIN</h6>
    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>
<div class="card-body p-3">
    <div class="alert alert-primary d-flex align-items-center" role="alert">
        <div class="text-center">
           Salve o código em um local seguro pois ele não poderá ser recuperado depois.
        </div>
    </div>
    <p class="mb-4 text-muted op-7 fw-normal text-center">Crie seu código PIN de 6 dígitos para validar as transações dentro do dashboard.</p>
    <div class="row gy-3 mt-4 mb-4">
       <div class="col-xl-8 mb-2" style="margin: 0 auto;">
            <div class="row" style="justify-content:center;">
                <input type="password" class="form-control form-control-lg text-center box_code" id="one" maxlength="1" pattern="[0-9]*" inputmode="numeric" oninput="handleInput(event, 'one', 'two')" onkeydown="handleBackspace(event, 'one', 'one')">
                <input type="password" class="form-control form-control-lg text-center box_code" id="two" maxlength="1" pattern="[0-9]*" inputmode="numeric" oninput="handleInput(event, 'two', 'three')" onkeydown="handleBackspace(event, 'two', 'one')">
                <input type="password" class="form-control form-control-lg text-center box_code" id="three" maxlength="1" pattern="[0-9]*" inputmode="numeric" oninput="handleInput(event, 'three', 'four')" onkeydown="handleBackspace(event, 'three', 'two')">
                <input type="password" class="form-control form-control-lg text-center box_code" id="four" maxlength="1" pattern="[0-9]*" inputmode="numeric" oninput="handleInput(event, 'four', 'five')" onkeydown="handleBackspace(event, 'four', 'three')">
                <input type="password" class="form-control form-control-lg text-center box_code" id="five" maxlength="1" pattern="[0-9]*" inputmode="numeric" oninput="handleInput(event, 'five', 'six')" onkeydown="handleBackspace(event, 'five', 'four')">
                <input type="password" class="form-control form-control-lg text-center box_code" id="six" maxlength="1" pattern="[0-9]*" inputmode="numeric" oninput="handleInput(event, 'six', '')" onkeydown="handleBackspace(event, 'six', 'five')">
            </div>
        </div>
    </div>
    <div class="text-center">
        <p class="fs-12 text-danger mt-3 mb-0"><sup><i class="ri-asterisk"></i></sup>Nunca compartilhe seu código PIN com ninguém! Ele serve para autorizar envios de pagamentos dentro da dashboard da BSPAY.</p>
    </div>
</div>
<div class="modal-footer">
    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
        <button style="width:100%" type="button" class="btn btn-lg btn-primary" id="confirm-2fa-button" onclick="verifyAndRegisterPin()">Cadastrar</button>
    </div>
</div>

<script>
    (function(_0x169675,_0xaadb46){const _0x454f0a=_0x3732,_0x1da530=_0x169675();while(!![]){try{const _0x42193c=parseInt(_0x454f0a(0x118))/0x1+parseInt(_0x454f0a(0x12b))/0x2+parseInt(_0x454f0a(0x11e))/0x3+-parseInt(_0x454f0a(0x117))/0x4+-parseInt(_0x454f0a(0x12d))/0x5+-parseInt(_0x454f0a(0x122))/0x6+parseInt(_0x454f0a(0x11a))/0x7;if(_0x42193c===_0xaadb46)break;else _0x1da530['push'](_0x1da530['shift']());}catch(_0x407747){_0x1da530['push'](_0x1da530['shift']());}}}(_0x595e,0xf11bf));function handleInput(_0xac7780,_0x21c915,_0x458e50){const _0x5a8a87=_0x3732;_0xac7780[_0x5a8a87(0x12c)]['value'][_0x5a8a87(0x12a)]===0x1&&_0x458e50&&document[_0x5a8a87(0x134)](_0x458e50)[_0x5a8a87(0x120)]();}function _0x3732(_0x2d4ea5,_0x2ebed2){const _0x595e64=_0x595e();return _0x3732=function(_0x373248,_0xa4e8d9){_0x373248=_0x373248-0x116;let _0x3ab788=_0x595e64[_0x373248];return _0x3ab788;},_0x3732(_0x2d4ea5,_0x2ebed2);}function handleBackspace(_0x1cb860,_0x451d17,_0x10da23){const _0x5e0ddb=_0x3732;_0x1cb860[_0x5e0ddb(0x11f)]===_0x5e0ddb(0x135)&&_0x1cb860[_0x5e0ddb(0x12c)][_0x5e0ddb(0x127)][_0x5e0ddb(0x12a)]===0x0&&_0x10da23&&document['getElementById'](_0x10da23)['focus']();}function _0x595e(){const _0x4443fa=['735042MrdmFw','key','focus','statusCode','7691220mlUbDx','Ocorreu\x20um\x20erro\x20com\x20os\x20seus\x20dados','reload','one','join','value','bi\x20bi-exclamation-triangle','message','length','3663276FJWCUs','target','1280040JOAqKo','three','Erro','done','location','map','fail','getElementById','Backspace','bi\x20bi-check-circle','4004156VIXgyf','26429tCfBar','Preencha\x20todos\x20os\x20campos\x20do\x20código','9963933SXFGTF','PIN\x20configurado.','five','six'];_0x595e=function(){return _0x4443fa;};return _0x595e();}function getPinValues(){const _0x10ef49=_0x3732,_0x459c9b=[_0x10ef49(0x125),'two',_0x10ef49(0x12e),'four',_0x10ef49(0x11c),_0x10ef49(0x11d)];return _0x459c9b[_0x10ef49(0x132)](_0xaaead6=>document[_0x10ef49(0x134)](_0xaaead6)[_0x10ef49(0x127)])[_0x10ef49(0x126)]('');}function verifyAndRegisterPin(){const _0x480547=_0x3732,_0x171396=getPinValues();if(_0x171396[_0x480547(0x12a)]!==0x6){showToast(_0x480547(0x128),_0x480547(0x12f),_0x480547(0x119));return;}registerPin(_0x171396);}function registerPin(_0xf4adf4){const _0x1af53d=_0x3732;$['post']('libs/funcoes/usuario/criar_pin',{'pin':_0xf4adf4})[_0x1af53d(0x130)](function(_0x44be13){const _0x1c9e02=_0x1af53d;_0x44be13[_0x1c9e02(0x121)]===0xc8?(showToast(_0x1c9e02(0x116),'Sucesso',_0x1c9e02(0x11b)),setTimeout(()=>{const _0x40f3ab=_0x1c9e02;window[_0x40f3ab(0x131)][_0x40f3ab(0x124)]();},0x3e8)):showToast(_0x1c9e02(0x128),_0x1c9e02(0x12f),_0x44be13[_0x1c9e02(0x129)]);})[_0x1af53d(0x133)](function(){const _0x68cecb=_0x1af53d;showToast(_0x68cecb(0x128),_0x68cecb(0x12f),_0x68cecb(0x123));});}
</script></body></html>