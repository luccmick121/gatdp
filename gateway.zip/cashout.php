
<!DOCTYPE html>

<html lang="pt-br" dir="ltr" data-nav-layout="vertical" data-theme-mode="light" data-header-styles="light" data-menu-styles="light" data-toggled="close">



<head>



    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <title> <?php include 'libs/get_site_name.php'; ?> - Saidas </title>

    <meta name="Description" content="Dashboard principal do gateway de pagamento <?php include 'libs/get_site_name.php'; ?>">

    <meta name="Author" content="Ellodev">

	<meta name="keywords" content="Gateway de pagamento">

    

    <!-- Favicon -->

    <link rel="icon" href="<?php include 'libs/get_site_favicon.php'; ?>" type="image/x-icon">

    

    <!-- Choices JS -->

    <script src="assets/libs/choices.js/public/assets/scripts/choices.min.js"></script>



    <!-- Main Theme Js -->

    <script src="assets/js/main.js"></script>

    

    <!-- Bootstrap Css -->

    <link id="style" href="assets/libs/bootstrap/css/bootstrap.min.css" rel="stylesheet" >



    <!-- Style Css -->

    <?php include 'libs/config_css.php'; ?>



    <!-- Icons Css -->

    <link href="assets/css/icons.css" rel="stylesheet" >



    <!-- Node Waves Css -->

    <link href="assets/libs/node-waves/waves.min.css" rel="stylesheet" > 



    <!-- Simplebar Css -->

    <link href="assets/libs/simplebar/simplebar.min.css" rel="stylesheet" >

    

    <!-- Color Picker Css -->

    <link rel="stylesheet" href="assets/libs/flatpickr/flatpickr.min.css">

    <link rel="stylesheet" href="assets/libs/@simonwep/pickr/themes/nano.min.css">



    <!-- Choices Css -->

    <link rel="stylesheet" href="assets/libs/choices.js/public/assets/styles/choices.min.css">


    <?php
    try {
        // Definir variáveis de conexão
        $dbHost = $_ENV['DB_HOST'];
        $dbnome = $_ENV['DB_NAME'];
        $dbUser = $_ENV['DB_USER'];
        $dbPass = $_ENV['DB_PASS'];

        // Conectar ao banco de dados
        $dsn = "mysql:host=$dbHost;dbname=$dbnome;charset=utf8";
        $pdo = new PDO($dsn, $dbUser, $dbPass);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Consultar as cores RGB armazenadas no banco de dados
        $query = "SELECT primary_color, secondary_color FROM config LIMIT 1"; // Supondo que as cores estejam na tabela config
        $stmt = $pdo->prepare($query);
        $stmt->execute();
        $config = $stmt->fetch(PDO::FETCH_ASSOC);

        // Obter as cores RGB do banco, caso não existam, usar valores padrão
        $primaryRgb = isset($config['primary_color']) ? $config['primary_color'] : '0, 203, 161'; // Exemplo de RGB padrão
        $secondaryRgb = isset($config['secondary_color']) ? $config['secondary_color'] : '69, 214, 91'; // Exemplo de RGB padrão
    } catch (PDOException $e) {
        die("Erro ao conectar ao banco de dados: " . $e->getMessage());
    }
    ?>

    <style>
        :root {
            --primary-rgb: <?php echo $primaryRgb; ?>;
            --secondary-rgb: <?php echo $secondaryRgb; ?>;
            --success-rgb: <?php echo $primaryRgb; ?>;
        }

        .box_code {
            padding-inline: 0;
            border: 1px solid rgb(<?php echo $primaryRgb; ?>);
            width: 39px;
            height: 39px;
            margin: 0px 4px;
            border-radius: 10px;
        }
    </style>



</head>



<body>

    <div id="loader">

        <img src="assets/images/media/loader.svg" alt="">

    </div>



    <div class="page">

            <!-- Start Switcher -->
    <div class="offcanvas offcanvas-end" tabindex="-1" id="switcher-canvas" aria-labelledby="offcanvasRightLabel">
    <div class="offcanvas-body">
        <div class="tab-content" id="nav-tabContent">
            <div class="tab-pane fade show active border-0" id="switcher-home" role="tabpanel" aria-labelledby="switcher-home-tab"
                tabindex="0">
                <div class="">
                    <p class="switcher-style-head">Theme Color Mode:</p>
                    <div class="row switcher-style gx-0">
                        <div class="col-4">
                            <div class="form-check switch-select">
                                <label class="form-check-label" for="switcher-light-theme">
                                    Light
                                </label>
                                <input class="form-check-input" type="radio" name="theme-style" id="switcher-light-theme"
                                    checked>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="form-check switch-select">
                                <label class="form-check-label" for="switcher-dark-theme">
                                    Dark
                                </label>
                                <input class="form-check-input" type="radio" name="theme-style" id="switcher-dark-theme">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="">
                    <p class="switcher-style-head">Directions:</p>
                    <div class="row switcher-style gx-0">
                        <div class="col-4">
                            <div class="form-check switch-select">
                                <label class="form-check-label" for="switcher-ltr">
                                    LTR
                                </label>
                                <input class="form-check-input" type="radio" name="direction" id="switcher-ltr" checked>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="form-check switch-select">
                                <label class="form-check-label" for="switcher-rtl">
                                    RTL
                                </label>
                                <input class="form-check-input" type="radio" name="direction" id="switcher-rtl">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="">
                    <p class="switcher-style-head">Navigation Styles:</p>
                    <div class="row switcher-style gx-0">
                        <div class="col-4">
                            <div class="form-check switch-select">
                                <label class="form-check-label" for="switcher-vertical">
                                    Vertical
                                </label>
                                <input class="form-check-input" type="radio" name="navigation-style" id="switcher-vertical"
                                    checked>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="form-check switch-select">
                                <label class="form-check-label" for="switcher-horizontal">
                                    Horizontal
                                </label>
                                <input class="form-check-input" type="radio" name="navigation-style"
                                    id="switcher-horizontal">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="navigation-menu-styles">
                    <p class="switcher-style-head">Vertical & Horizontal Menu Styles:</p>
                    <div class="row switcher-style gx-0 pb-2 gy-2">
                        <div class="col-4">
                            <div class="form-check switch-select">
                                <label class="form-check-label" for="switcher-menu-click">
                                    Menu Click
                                </label>
                                <input class="form-check-input" type="radio" name="navigation-menu-styles"
                                    id="switcher-menu-click">
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="form-check switch-select">
                                <label class="form-check-label" for="switcher-menu-hover">
                                    Menu Hover
                                </label>
                                <input class="form-check-input" type="radio" name="navigation-menu-styles"
                                    id="switcher-menu-hover">
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="form-check switch-select">
                                <label class="form-check-label" for="switcher-icon-click">
                                    Icon Click
                                </label>
                                <input class="form-check-input" type="radio" name="navigation-menu-styles"
                                    id="switcher-icon-click">
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="form-check switch-select">
                                <label class="form-check-label" for="switcher-icon-hover">
                                    Icon Hover
                                </label>
                                <input class="form-check-input" type="radio" name="navigation-menu-styles"
                                    id="switcher-icon-hover">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="sidemenu-layout-styles">
                    <p class="switcher-style-head">Sidemenu Layout Styles:</p>
                    <div class="row switcher-style gx-0 pb-2 gy-2">
                        <div class="col-sm-6">
                            <div class="form-check switch-select">
                                <label class="form-check-label" for="switcher-default-menu">
                                    Default Menu
                                </label>
                                <input class="form-check-input" type="radio" name="sidemenu-layout-styles"
                                    id="switcher-default-menu" checked>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-check switch-select">
                                <label class="form-check-label" for="switcher-closed-menu">
                                    Closed Menu
                                </label>
                                <input class="form-check-input" type="radio" name="sidemenu-layout-styles"
                                    id="switcher-closed-menu">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-check switch-select">
                                <label class="form-check-label" for="switcher-icontext-menu">
                                    Icon Text
                                </label>
                                <input class="form-check-input" type="radio" name="sidemenu-layout-styles"
                                    id="switcher-icontext-menu">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-check switch-select">
                                <label class="form-check-label" for="switcher-icon-overlay">
                                    Icon Overlay
                                </label>
                                <input class="form-check-input" type="radio" name="sidemenu-layout-styles"
                                    id="switcher-icon-overlay">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-check switch-select">
                                <label class="form-check-label" for="switcher-detached">
                                    Detached
                                </label>
                                <input class="form-check-input" type="radio" name="sidemenu-layout-styles"
                                    id="switcher-detached">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-check switch-select">
                                <label class="form-check-label" for="switcher-double-menu">
                                    Double Menu
                                </label>
                                <input class="form-check-input" type="radio" name="sidemenu-layout-styles"
                                    id="switcher-double-menu">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="">
                    <p class="switcher-style-head">Page Styles:</p>
                    <div class="row switcher-style gx-0">
                        <div class="col-4">
                            <div class="form-check switch-select">
                                <label class="form-check-label" for="switcher-regular">
                                    Regular
                                </label>
                                <input class="form-check-input" type="radio" name="page-styles" id="switcher-regular"
                                    checked>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="form-check switch-select">
                                <label class="form-check-label" for="switcher-classic">
                                    Classic
                                </label>
                                <input class="form-check-input" type="radio" name="page-styles" id="switcher-classic">
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="form-check switch-select">
                                <label class="form-check-label" for="switcher-modern">
                                    Modern
                                </label>
                                <input class="form-check-input" type="radio" name="page-styles" id="switcher-modern">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="">
                    <p class="switcher-style-head">Layout Width Styles:</p>
                    <div class="row switcher-style gx-0">
                        <div class="col-4">
                            <div class="form-check switch-select">
                                <label class="form-check-label" for="switcher-full-width">
                                    Full Width
                                </label>
                                <input class="form-check-input" type="radio" name="layout-width" id="switcher-full-width"
                                    checked>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="form-check switch-select">
                                <label class="form-check-label" for="switcher-boxed">
                                    Boxed
                                </label>
                                <input class="form-check-input" type="radio" name="layout-width" id="switcher-boxed">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="">
                    <p class="switcher-style-head">Menu Positions:</p>
                    <div class="row switcher-style gx-0">
                        <div class="col-4">
                            <div class="form-check switch-select">
                                <label class="form-check-label" for="switcher-menu-fixed">
                                    Fixed
                                </label>
                                <input class="form-check-input" type="radio" name="menu-positions" id="switcher-menu-fixed"
                                    checked>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="form-check switch-select">
                                <label class="form-check-label" for="switcher-menu-scroll">
                                    Scrollable
                                </label>
                                <input class="form-check-input" type="radio" name="menu-positions" id="switcher-menu-scroll">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="">
                    <p class="switcher-style-head">Header Positions:</p>
                    <div class="row switcher-style gx-0">
                        <div class="col-4">
                            <div class="form-check switch-select">
                                <label class="form-check-label" for="switcher-header-fixed">
                                    Fixed
                                </label>
                                <input class="form-check-input" type="radio" name="header-positions"
                                    id="switcher-header-fixed" checked>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="form-check switch-select">
                                <label class="form-check-label" for="switcher-header-scroll">
                                    Scrollable
                                </label>
                                <input class="form-check-input" type="radio" name="header-positions"
                                    id="switcher-header-scroll">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="">
                    <p class="switcher-style-head">Loader:</p>
                    <div class="row switcher-style gx-0">
                        <div class="col-4">
                            <div class="form-check switch-select">
                                <label class="form-check-label" for="switcher-loader-enable">
                                    Enable
                                </label>
                                <input class="form-check-input" type="radio" name="page-loader"
                                    id="switcher-loader-enable">
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="form-check switch-select">
                                <label class="form-check-label" for="switcher-loader-disable">
                                    Disable
                                </label>
                                <input class="form-check-input" type="radio" name="page-loader"
                                    id="switcher-loader-disable" checked>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="tab-pane fade border-0" id="switcher-profile" role="tabpanel" aria-labelledby="switcher-profile-tab" tabindex="0">
                <div>
                    <div class="theme-colors">
                        <p class="switcher-style-head">Menu Colors:</p>
                        <div class="d-flex switcher-style pb-2">
                            <div class="form-check switch-select me-3">
                                <input class="form-check-input color-input color-white" data-bs-toggle="tooltip"
                                    data-bs-placement="top" title="Light Menu" type="radio" name="menu-colors"
                                    id="switcher-menu-light" checked>
                            </div>
                            <div class="form-check switch-select me-3">
                                <input class="form-check-input color-input color-dark" data-bs-toggle="tooltip"
                                    data-bs-placement="top" title="Dark Menu" type="radio" name="menu-colors"
                                    id="switcher-menu-dark">
                            </div>
                            <div class="form-check switch-select me-3">
                                <input class="form-check-input color-input color-primary" data-bs-toggle="tooltip"
                                    data-bs-placement="top" title="Color Menu" type="radio" name="menu-colors"
                                    id="switcher-menu-primary">
                            </div>
                            <div class="form-check switch-select me-3">
                                <input class="form-check-input color-input color-gradient" data-bs-toggle="tooltip"
                                    data-bs-placement="top" title="Gradient Menu" type="radio" name="menu-colors"
                                    id="switcher-menu-gradient">
                            </div>
                            <div class="form-check switch-select me-3">
                                <input class="form-check-input color-input color-transparent"
                                    data-bs-toggle="tooltip" data-bs-placement="top" title="Transparent Menu"
                                    type="radio" name="menu-colors" id="switcher-menu-transparent">
                            </div>
                        </div>
                        <div class="px-4 pb-3 text-muted fs-11">Note:If you want to change color Menu dynamically change from below Theme Primary color picker</div>
                    </div>
                    <div class="theme-colors">
                        <p class="switcher-style-head">Header Colors:</p>
                        <div class="d-flex switcher-style pb-2">
                            <div class="form-check switch-select me-3">
                                <input class="form-check-input color-input color-white" data-bs-toggle="tooltip"
                                    data-bs-placement="top" title="Light Header" type="radio" name="header-colors"
                                    id="switcher-header-light" checked>
                            </div>
                            <div class="form-check switch-select me-3">
                                <input class="form-check-input color-input color-dark" data-bs-toggle="tooltip"
                                    data-bs-placement="top" title="Dark Header" type="radio" name="header-colors"
                                    id="switcher-header-dark">
                            </div>
                            <div class="form-check switch-select me-3">
                                <input class="form-check-input color-input color-primary" data-bs-toggle="tooltip"
                                    data-bs-placement="top" title="Color Header" type="radio" name="header-colors"
                                    id="switcher-header-primary">
                            </div>
                            <div class="form-check switch-select me-3">
                                <input class="form-check-input color-input color-gradient" data-bs-toggle="tooltip"
                                    data-bs-placement="top" title="Gradient Header" type="radio" name="header-colors"
                                    id="switcher-header-gradient">
                            </div>
                            <div class="form-check switch-select me-3">
                                <input class="form-check-input color-input color-transparent" data-bs-toggle="tooltip"
                                    data-bs-placement="top" title="Transparent Header" type="radio" name="header-colors"
                                    id="switcher-header-transparent">
                            </div>
                        </div>
                        <div class="px-4 pb-3 text-muted fs-11">Note:If you want to change color Header dynamically change from below Theme Primary color picker</div>
                    </div>
                    <div class="theme-colors">
                        <p class="switcher-style-head">Theme Primary:</p>
                        <div class="d-flex flex-wrap align-items-center switcher-style">
                            <div class="form-check switch-select me-3">
                                <input class="form-check-input color-input color-primary-1" type="radio"
                                    name="theme-primary" id="switcher-primary">
                            </div>
                            <div class="form-check switch-select me-3">
                                <input class="form-check-input color-input color-primary-2" type="radio"
                                    name="theme-primary" id="switcher-primary1">
                            </div>
                            <div class="form-check switch-select me-3">
                                <input class="form-check-input color-input color-primary-3" type="radio" name="theme-primary"
                                    id="switcher-primary2">
                            </div>
                            <div class="form-check switch-select me-3">
                                <input class="form-check-input color-input color-primary-4" type="radio" name="theme-primary"
                                    id="switcher-primary3">
                            </div>
                            <div class="form-check switch-select me-3">
                                <input class="form-check-input color-input color-primary-5" type="radio" name="theme-primary"
                                    id="switcher-primary4">
                            </div>
                            <div class="form-check switch-select ps-0 mt-1 color-primary-light">
                                <div class="theme-container-primary"></div>
                                <div class="pickr-container-primary"  onchange="updateChartColor(this.value)"></div>
                            </div>
                        </div>
                    </div>
                    <div class="theme-colors">
                        <p class="switcher-style-head">Theme Background:</p>
                        <div class="d-flex flex-wrap align-items-center switcher-style">
                            <div class="form-check switch-select me-3">
                                <input class="form-check-input color-input color-bg-1" type="radio"
                                    name="theme-background" id="switcher-background">
                            </div>
                            <div class="form-check switch-select me-3">
                                <input class="form-check-input color-input color-bg-2" type="radio"
                                    name="theme-background" id="switcher-background1">
                            </div>
                            <div class="form-check switch-select me-3">
                                <input class="form-check-input color-input color-bg-3" type="radio" name="theme-background"
                                    id="switcher-background2">
                            </div>
                            <div class="form-check switch-select me-3">
                                <input class="form-check-input color-input color-bg-4" type="radio"
                                    name="theme-background" id="switcher-background3">
                            </div>
                            <div class="form-check switch-select me-3">
                                <input class="form-check-input color-input color-bg-5" type="radio"
                                    name="theme-background" id="switcher-background4">
                            </div>
                            <div class="form-check switch-select ps-0 mt-1 tooltip-static-demo color-bg-transparent">
                                <div class="theme-container-background"></div>
                                <div class="pickr-container-background"></div>
                            </div>
                        </div>
                    </div>
                    <div class="menu-image mb-3">
                        <p class="switcher-style-head">Menu With Background Image:</p>
                        <div class="d-flex flex-wrap align-items-center switcher-style">
                            <div class="form-check switch-select m-2">
                                <input class="form-check-input bgimage-input bg-img1" type="radio"
                                    name="theme-background" id="switcher-bg-img">
                            </div>
                            <div class="form-check switch-select m-2">
                                <input class="form-check-input bgimage-input bg-img2" type="radio"
                                    name="theme-background" id="switcher-bg-img1">
                            </div>
                            <div class="form-check switch-select m-2">
                                <input class="form-check-input bgimage-input bg-img3" type="radio" name="theme-background"
                                    id="switcher-bg-img2">
                            </div>
                            <div class="form-check switch-select m-2">
                                <input class="form-check-input bgimage-input bg-img4" type="radio"
                                    name="theme-background" id="switcher-bg-img3">
                            </div>
                            <div class="form-check switch-select m-2">
                                <input class="form-check-input bgimage-input bg-img5" type="radio"
                                    name="theme-background" id="switcher-bg-img4">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="d-flex justify-content-center canvas-footer flex-wrap">
                <a href="javascript:void(0);" id="reset-all" class="btn btn-danger m-1 w-100">Reset</a> 
            </div>
        </div>
    </div>
</div>
<header class="app-header">
    <div class="main-header-container container-fluid">
        <div class="header-content-left">
            <div class="header-element">
                <div class="horizontal-logo">
                    <a href="./" class="header-logo">
                        <img src="<?php include 'libs/get_site_logo.php'; ?>" alt="logo" class="desktop-logo">
                        <img src="<?php include 'libs/get_site_toggle_logo.php'; ?>" alt="logo" class="toggle-logo">
                        <img src="<?php include 'libs/get_site_logo.php'; ?>" alt="logo" class="desktop-dark">
                        <img src="<?php include 'libs/get_site_toggle_logo.php'; ?>" alt="logo" class="toggle-dark">
                    </a>
                </div>
            </div>
            <div class="header-element mx-lg-0 mx-2 sidemenu-toggle" data-bs-toggle="sidebar">
                <a aria-label="Hide Sidebar" class="header-link animated-arrow hor-toggle horizontal-navtoggle"><span></span></a>
            </div>
        </div>
        <ul class="header-content-right">
            <li class="header-element header-theme-mode">
                <a href="javascript:void(0);" class="header-link layout-setting">
                    <span class="light-layout">
                        <i class="bi bi-moon header-link-icon"></i>
                    </span>
                    <span class="dark-layout">
                        <i class="bi bi-brightness-high header-link-icon"></i>
                    </span>
                </a>
            </li>
            <li class="header-element notifications-dropdown d-xl-block d-none">
                <a href="javascript:void(0);" class="header-link dropdown-toggle" data-bs-toggle="dropdown" data-bs-auto-close="outside" id="messageDropdown" aria-expanded="false">
                    <i class="bi bi-bell header-link-icon"></i>
                    <span class="header-icon-pulse bg-secondary rounded pulse pulse-secondary"></span>
                </a>
                <div class="main-header-dropdown dropdown-menu dropdown-menu-end" data-popper-placement="none">
                    <div class="p-3">
                        <div class="d-flex align-items-center justify-content-between">
                            <p class="mb-0 fs-16">Notificações</p>
                            <span class="badge bg-secondary-transparent d-none" id="notifiation-data">0 Notificações</span>
                        </div>
                    </div>
                    <div class="dropdown-divider"></div>
                    <div class="p-5 empty-item1">
                        <div class="text-center">
                            <span class="avatar avatar-xl avatar-rounded bg-secondary-transparent">
                                <i class="ri-notification-off-line fs-2"></i>
                            </span>
                            <h6 class="fw-medium mt-3">Não existem notificações</h6>
                        </div>
                    </div>
                </div>
            </li>
            <li class="header-element">
                <a href="javascript:void(0);" class="header-link dropdown-toggle" id="mainHeaderProfile" data-bs-toggle="dropdown" data-bs-auto-close="outside" aria-expanded="false">
                    <i class="ri-user-line header-link-icon"></i>
                </a>
                <ul class="main-header-dropdown dropdown-menu pt-0 overflow-hidden header-profile-dropdown dropdown-menu-end" aria-labelledby="mainHeaderProfile">
                    <li><a class="dropdown-item d-flex align-items-center" href="profile"><i class="bi bi-person fs-18 me-2 op-7"></i>Perfil</a></li>
                    <li><a class="dropdown-item d-flex align-items-center" href="logout"><i class="bi bi-box-arrow-right fs-18 me-2 op-7"></i>Sair</a></li>
                </ul>
            </li>  
        </ul>
    </div>
</header>

        <aside class="app-sidebar sticky" id="sidebar">
    <div class="main-sidebar-header">
        <a href="./" class="header-logo d-flex align-items-center">
            <div>
                <img src="<?php include 'libs/get_site_logo.php'; ?>" alt="logo" class="desktop-logo">
                <img src="<?php include 'libs/get_site_toggle_logo.php'; ?>" alt="logo" class="toggle-dark mini_logo">
                <img src="<?php include 'libs/get_site_logo.php'; ?>" alt="logo" class="desktop-dark">
                <img src="<?php include 'libs/get_site_toggle_logo.php'; ?>" alt="logo" class="toggle-logo mini_logo">
            </div>
            <?php include 'libs/check_pay_logo.php'; ?>
        </a>
    </div>
    <div class="main-sidebar" id="sidebar-scroll">
        <nav class="main-menu-container nav nav-pills flex-column sub-open">
            <div class="slide-left" id="slide-left">
                <svg xmlns="http://www.w3.org/2000/svg" fill="#7b8191" width="24" height="24" viewBox="0 0 24 24"> <path d="M13.293 6.293 7.586 12l5.707 5.707 1.414-1.414L10.414 12l4.293-4.293z"></path> </svg>
            </div>
            <ul class="main-menu">
                <li class="slide">
                    <a href="./" class="side-menu__item">
                        <i class="bi bi-house side-menu__icon"></i>
                        <span class="side-menu__label">Dashboard</span>
                    </a>
                </li>
                <li class="slide">
                    <a class="side-menu__item openModal" data-target="libs/includes/falar_gerente">
                        <i class="ri-customer-service-2-fill side-menu__icon"></i>
                        <span class="side-menu__label">Fale com seu Gerente</span>
                    </a>
                </li>
                
                        
                            <li class="slide has-sub">
                                <a href="javascript:void(0);" class="side-menu__item">
                                    <i class="bi bi-arrow-down-up side-menu__icon"></i>
                                    <span class="side-menu__label">Transferências</span>
                                    <i class="fe fe-chevron-right side-menu__angle"></i>
                                </a>
                                <ul class="slide-menu child1 pages-ul">
                                    <li class="slide side-menu__label1">
                                        <a href="javascript:void(0)">Transferências</a>
                                    </li>
                                    <li class="slide">
                                        <a data-target="libs/includes/gerar_pix" class="side-menu__item openModal">Receber via Pix</a>
                                    </li>
                                    <li class="slide">
                                        <a data-target="libs/includes/gerar_saque" class="side-menu__item openModal">Transferir via Pix</a>
                                    </li>
                                    <li class="slide">
                                        <a data-target="libs/includes/transferencia_interna" class="side-menu__item openModal">Transferência Interna</a>
                                    </li>
                                </ul>
                            </li>
                            <li class="slide has-sub">
                                <a href="javascript:void(0);" class="side-menu__item">
                                    <i class="bi bi-graph-up side-menu__icon"></i>
                                    <span class="side-menu__label">Relatórios</span>
                                    <i class="fe fe-chevron-right side-menu__angle"></i>
                                </a>
                                <ul class="slide-menu child1 pages-ul">
                                    <li class="slide side-menu__label1">
                                        <a href="javascript:void(0)">Relatórios</a>
                                    </li>
                                    <li class="slide">
                                        <a href="cashin" class="side-menu__item">Entradas PIX</a>
                                    </li>
                                    <li class="slide">
                                        <a href="cashout" class="side-menu__item">Saídas PIX</a>
                                    </li>
                                    <li class="slide">
                                        <a href="internal_transfer" class="side-menu__item">Transferência Interna</a>
                                    </li>
                                    <!-- <li class="slide">
                                        <a href="webhooks" class="side-menu__item">Webhooks</a>
                                    </li> !-->
                                </ul>
                            </li>
                            <li class="slide has-sub">
                                <a href="javascript:void(0);" class="side-menu__item">
                                    <i class="bi bi-code-slash side-menu__icon"></i>
                                    <span class="side-menu__label">API</span>
                                    <i class="fe fe-chevron-right side-menu__angle"></i>
                                </a>
                                <ul class="slide-menu child1 pages-ul">
                                    <li class="slide side-menu__label1">
                                        <a href="javascript:void(0)">API</a>
                                    </li>
                                    <li class="slide">
                                        <a href="keys" class="side-menu__item">Credenciais</a>
                                    </li>
                                    <li class="slide">
                                        <a href="https://dev.bspay.co" target="_blank" class="side-menu__item">Documentação</a>
                                    </li>
                                </ul>
                            </li>

                                        <li class="slide">
                    <a href="settings" class="side-menu__item">
                        <i class="bi bi-gear side-menu__icon"></i>
                        <span class="side-menu__label">Configurações</span>
                    </a>
                </li>
            </ul>
            <div class="slide-right" id="slide-right"><svg xmlns="http://www.w3.org/2000/svg" fill="#7b8191" width="24" height="24" viewBox="0 0 24 24"> <path d="M10.707 17.707 16.414 12l-5.707-5.707-1.414 1.414L13.586 12l-4.293 4.293z"></path> </svg></div>
        </nav>
    </div>
</aside>
        <!-- Start::app-content -->

        <div class="main-content app-content">

            <div class="container-fluid">



                <!-- Start::page-header -->

                <div class="mb-4 page-header-breadcrumb d-flex align-items-center justify-content-between flex-wrap gap-2">

                    <div>

                        <p class="fw-medium fs-20 mb-0">Saídas</p>

                    </div>

                    <div class="col-md-3">

                        <div class="form-group">

                            <div class="input-group">

                                <div class="input-group-text text-muted"> <i class="ri-calendar-line"></i> </div>

                                <input type="text" class="form-control" id="daterange" placeholder="Selecionar período">

                            </div>

                        </div>

                    </div>

                </div>

                <!-- End:page-header -->

                <!-- Start:: row-1 -->

                <div class="row">

                    <div class="col-lg-6 col-sm-6 col-md-6 col-xl-3">

                        <div class="card custom-card">

                            <div class="card-body">

                                <div class="d-flex align-items-start gap-4 flex-wrap">

                                    <div class="flex-fill d-flex align-items-center justify-content-between flex-wrap gap-3">

                                        <div>

                                            <div class="mb-3">Qtd. Saques</div>

                                            <div class="text-muted mb-1 fs-12">

                                                <span id="qtd-saques" class="text-dark fs-20 lh-1 vertical-bottom">

                                                    0

                                                </span>

                                            </div>

                                        </div>

                                    </div>

                                </div>

                            </div>

                        </div>

                    </div>

                    <div class="col-lg-6 col-sm-6 col-md-6 col-xl-3">

                        <div class="card custom-card">

                            <div class="card-body">

                                <div class="d-flex align-items-start gap-4 flex-wrap">

                                    <div class="flex-fill d-flex align-items-center justify-content-between flex-wrap gap-3">

                                        <div>

                                            <div class="mb-3">Total sacado</div>

                                            <div class="text-muted mb-1 fs-12">

                                                <span id="total-sacado" class="text-dark fs-20 lh-1 vertical-bottom">

                                                    R$ 0,00

                                                </span>

                                            </div>

                                        </div>

                                    </div>

                                </div>

                            </div>

                        </div>

                    </div>

                    <div class="col-lg-6 col-sm-6 col-md-6 col-xl-3">

                        <div class="card custom-card">

                            <div class="card-body">

                                <div class="d-flex align-items-start gap-4 flex-wrap">

                                    <div class="flex-fill d-flex align-items-center justify-content-between flex-wrap gap-3">

                                        <div>

                                            <div class="mb-3">Tarifas de saques</div>

                                            <div class="text-muted mb-1 fs-12">

                                                <span id="tarifas-saques" class="text-dark fs-20 lh-1 vertical-bottom">

                                                    R$ 0,00

                                                </span>

                                            </div>

                                        </div>

                                    </div>

                                </div>

                            </div>

                        </div>

                    </div>

                    <div class="col-lg-6 col-sm-6 col-md-6 col-xl-3">

                        <div class="card custom-card">

                            <div class="card-body">

                                <div class="d-flex align-items-start gap-4 flex-wrap">

                                    <div class="flex-fill d-flex align-items-center justify-content-between flex-wrap gap-3">

                                        <div>

                                            <div class="mb-3">Ticket médio</div>

                                            <div class="text-muted mb-1 fs-12">

                                                <span id="ticket-medio" class="text-dark fs-20 lh-1 vertical-bottom">

                                                    R$ 0,00

                                                </span>

                                            </div>

                                        </div>

                                    </div>    

                                </div>

                            </div>

                        </div>

                    </div>

                </div>

                <button type="button" data-target="libs/includes/gerar_saque" class="btn btn-primary mb-4 btn-wave waves-effect waves-light openModal">GERAR NOVO SAQUE</button>

                <div class="row">

                    <div class="col-xl-12">

                        <div class="card custom-card">

                            <div class="card-body">

                                <div class="table-responsive">

                                    <table id="file-export" class="table text-nowrap w-100">

                                        <thead>

                                            <tr>

                                                <th>ID da transação</th>

                                                <th>Data Gerado</th>

                                                <th>Data Confirmado</th>

                                                <th>Código END2END</th>

                                                <th>Descrição</th>

                                                <th>Valor</th>

                                                <th>Taxa</th>

                                                <th>Status</th>

                                                <th>Comprovante</th>

                                            </tr>

                                        </thead>

                                        <tbody id="transacoes-body">

                                            <!-- Os dados serão preenchidos aqui -->

                                        </tbody>

                                    </table>

                                </div>

                            </div>

                        </div>

                    </div>

                </div>



            </div>

        </div>

    </div>

    <div id="responsive-overlay"></div>

    <script src="assets/js/jquery-3.6.1.min.js"></script>

    <!-- Popper JS -->

    <script src="assets/libs/@popperjs/core/umd/popper.min.js"></script>



    <!-- Bootstrap JS -->

    <script src="assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>



    <!-- Defaultmenu JS -->

    <script src="assets/js/defaultmenu.min.js"></script>



    <!-- Node Waves JS-->

    <script src="assets/libs/node-waves/waves.min.js"></script>



    <!-- Sticky JS -->

    <script src="assets/js/sticky.js"></script>



    <!-- Simplebar JS -->

    <script src="assets/libs/simplebar/simplebar.min.js"></script>

    <script src="assets/js/simplebar.js"></script>



    <!-- Color Picker JS -->

    <script src="assets/libs/@simonwep/pickr/pickr.es5.min.js"></script>

    <script src="assets/libs/flatpickr/flatpickr.min.js"></script>

    <script src="assets/js/date&time_pickers.js"></script>

        

    <!-- Custom-Switcher JS -->

    <script src="assets/js/custom-switcher.min.js"></script>



    <script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>

    <script src="https://cdn.datatables.net/1.12.1/js/dataTables.bootstrap5.min.js"></script>

    <script src="https://cdn.datatables.net/responsive/2.3.0/js/dataTables.responsive.min.js"></script>

    <script src="assets/js/flatpickr-pt.js"></script>

    <script>

        function _0x4ee5(_0x319c3d,_0x31fd31){var _0x46f213=_0x46f2();return _0x4ee5=function(_0x4ee59a,_0x5e93c4){_0x4ee59a=_0x4ee59a-0xc1;var _0x405d52=_0x46f213[_0x4ee59a];return _0x405d52;},_0x4ee5(_0x319c3d,_0x31fd31);}(function(_0x2f783f,_0x34bf85){var _0x35da73=_0x4ee5,_0x4c692e=_0x2f783f();while(!![]){try{var _0x219901=parseInt(_0x35da73(0x10b))/0x1+-parseInt(_0x35da73(0xc2))/0x2*(parseInt(_0x35da73(0xe0))/0x3)+parseInt(_0x35da73(0xe4))/0x4+parseInt(_0x35da73(0x101))/0x5*(-parseInt(_0x35da73(0xdf))/0x6)+-parseInt(_0x35da73(0x112))/0x7*(parseInt(_0x35da73(0xf0))/0x8)+parseInt(_0x35da73(0x106))/0x9+parseInt(_0x35da73(0xd1))/0xa;if(_0x219901===_0x34bf85)break;else _0x4c692e['push'](_0x4c692e['shift']());}catch(_0x3227b6){_0x4c692e['push'](_0x4c692e['shift']());}}}(_0x46f2,0x58325),$(document)['ready'](function(){var _0x223f42=_0x4ee5;function _0x2011d7(){var _0x31bbf8=_0x4ee5,_0x3c3327=new Date(),_0x2ffa30=new Date(_0x3c3327[_0x31bbf8(0xd9)](),_0x3c3327[_0x31bbf8(0x10a)](),_0x3c3327['getDate']()),_0x576403=new Date(_0x3c3327[_0x31bbf8(0xd9)](),_0x3c3327[_0x31bbf8(0x10a)](),_0x3c3327[_0x31bbf8(0xc1)](),0x17,0x3b,0x3b);return[_0x2ffa30,_0x576403];}function _0x25e0e4(_0x3ac364){var _0x5a0f65=_0x4ee5,_0x57f0dc=('0'+_0x3ac364[_0x5a0f65(0xc1)]())[_0x5a0f65(0xee)](-0x2),_0x367f62=('0'+(_0x3ac364[_0x5a0f65(0x10a)]()+0x1))[_0x5a0f65(0xee)](-0x2),_0x2f634a=_0x3ac364[_0x5a0f65(0xd9)]();return _0x2f634a+'-'+_0x367f62+'-'+_0x57f0dc;}var _0x17860e=_0x2011d7(),_0x259c54=_0x17860e[_0x223f42(0xc6)](_0x3aaf06=>_0x25e0e4(_0x3aaf06));$('#daterange')[_0x223f42(0xdd)]({'mode':_0x223f42(0xe1),'dateFormat':_0x223f42(0xc9),'locale':'pt','defaultDate':_0x17860e,'onClose':function(_0x2dac77,_0x31387b,_0xdcaea3){var _0x4cb554=_0x223f42;if(_0x2dac77['length']===0x2){var _0x378b6a=_0x2dac77[0x0][_0x4cb554(0xe7)]()[_0x4cb554(0xc4)]('T')[0x0]+_0x4cb554(0x10d),_0x483f79=_0x2dac77[0x1][_0x4cb554(0xe7)]()['split']('T')[0x0]+'\x2023:59:59';_0xd266ab(_0x378b6a,_0x483f79),_0xf676a1(_0x378b6a,_0x483f79);}}});function _0xf676a1(_0x43e2b4,_0x2886cd){var _0x158658=_0x223f42;$[_0x158658(0xd5)]({'url':_0x158658(0x10f),'method':_0x158658(0xe5),'data':{'data_inicial':_0x43e2b4,'data_final':_0x2886cd},'success':function(_0x4f2604){var _0x17285f=_0x158658;if(_0x4f2604&&_0x4f2604[_0x17285f(0xd4)]!==undefined&&_0x4f2604[_0x17285f(0x113)]!==undefined&&_0x4f2604['totalTaxasSaidas']!==undefined){$('#qtd-saques')['text'](_0x4f2604['quantidadeSaques']),$(_0x17285f(0xff))[_0x17285f(0xe3)](_0x17285f(0xf7)+_0x4f2604[_0x17285f(0x113)][_0x17285f(0xc7)]('pt-BR',{'minimumFractionDigits':0x2,'maximumFractionDigits':0x2})),$(_0x17285f(0xf3))[_0x17285f(0xe3)]('R$\x20'+_0x4f2604[_0x17285f(0xd7)][_0x17285f(0xc7)]('pt-BR',{'minimumFractionDigits':0x2,'maximumFractionDigits':0x2}));var _0x48019c=_0x4f2604[_0x17285f(0xd4)]>0x0?_0x4f2604[_0x17285f(0x113)]/_0x4f2604[_0x17285f(0xd4)]:0x0;$('#ticket-medio')['text'](_0x17285f(0xf7)+_0x48019c[_0x17285f(0xc7)]('pt-BR',{'minimumFractionDigits':0x2,'maximumFractionDigits':0x2}));}else $('#qtd-saques')[_0x17285f(0xe3)]('0'),$('#total-sacado')[_0x17285f(0xe3)](_0x17285f(0xed)),$('#tarifas-saques')[_0x17285f(0xe3)](_0x17285f(0xed)),$(_0x17285f(0xd8))[_0x17285f(0xe3)](_0x17285f(0xed)),console['error'](_0x17285f(0xe6),_0x4f2604);},'error':function(_0xa6302f,_0x5a0894,_0x3a8ed9){console['error']('Erro\x20ao\x20buscar\x20relatório\x20por\x20período:',_0x5a0894,_0x3a8ed9);}});}function _0xd266ab(_0x2b7716,_0x29db98){var _0x2de49d=_0x223f42;$(_0x2de49d(0xd0))[_0x2de49d(0x102)]()['ajax']['url'](_0x2de49d(0xda)+_0x2b7716+_0x2de49d(0xde)+_0x29db98)[_0x2de49d(0x109)]();}var _0x58dc67=$('#file-export')[_0x223f42(0x102)]({'lengthMenu':[[0x64,0xc8,0x1f4,0x3e8],[0x64,0xc8,0x1f4,0x3e8]],'language':{'searchPlaceholder':_0x223f42(0xcc),'sSearch':'','sEmptyTable':_0x223f42(0xec),'sInfo':'Mostrando\x20de\x20_START_\x20até\x20_END_\x20de\x20_TOTAL_\x20registros','sInfoEmpty':_0x223f42(0xd3),'sInfoFiltered':_0x223f42(0x110),'sInfoPostFix':'','sInfoThousands':'.','sLengthMenu':_0x223f42(0x103),'sLoadingRecords':_0x223f42(0xf6),'sProcessing':_0x223f42(0xf1),'sZeroRecords':'Nenhum\x20registro\x20encontrado','sPaginate':{'sFirst':_0x223f42(0xca),'sLast':_0x223f42(0xf5),'sNext':_0x223f42(0xd2),'sPrevious':'Anterior'},'sAria':{'sSortAscending':':\x20Ordenar\x20colunas\x20de\x20forma\x20ascendente','sSortDescending':_0x223f42(0xc8)},'oPaginate':{'sFirst':_0x223f42(0xca),'sPrevious':'Anterior','sNext':'Próximo','sLast':_0x223f42(0xf5)},'oAria':{'sSortAscending':_0x223f42(0x10c),'sSortDescending':':\x20Ordenar\x20colunas\x20de\x20forma\x20descendente'}},'processing':!![],'serverSide':!![],'ajax':{'url':_0x223f42(0xfd),'type':_0x223f42(0xe5),'data':function(_0x5926c2){var _0xc49abd=_0x223f42,_0x52001b=$(_0xc49abd(0xcf))[_0xc49abd(0xfb)]()[_0xc49abd(0xc4)](_0xc49abd(0xcd));_0x5926c2['data_inicial']=_0x52001b[0x0]?_0x52001b[0x0]+_0xc49abd(0x10d):new Date(new Date()['getFullYear'](),new Date()[_0xc49abd(0x10a)](),0x1)[_0xc49abd(0xe7)]()['split']('T')[0x0]+_0xc49abd(0x10d),_0x5926c2['data_final']=_0x52001b[0x1]?_0x52001b[0x1]+_0xc49abd(0xd6):new Date()['toISOString']()['split']('T')[0x0]+_0xc49abd(0xd6);}},'columns':[{'data':'id'},{'data':null,'render':function(_0x3c0dcd,_0x472a1e,_0xf7fe81){var _0x563b5c=_0x223f42,_0x39322=new Date(_0xf7fe81[_0x563b5c(0x108)]);return _0x39322[_0x563b5c(0xef)](_0x39322[_0x563b5c(0x104)]()),_0x39322['getFullYear']()+'-'+('0'+(_0x39322[_0x563b5c(0x10a)]()+0x1))[_0x563b5c(0xee)](-0x2)+'-'+('0'+_0x39322[_0x563b5c(0xc1)]())[_0x563b5c(0xee)](-0x2)+'\x20'+('0'+_0x39322[_0x563b5c(0x104)]())[_0x563b5c(0xee)](-0x2)+':'+('0'+_0x39322[_0x563b5c(0xe2)]())['slice'](-0x2)+':'+('0'+_0x39322[_0x563b5c(0x111)]())[_0x563b5c(0xee)](-0x2);}},{'data':null,'render':function(_0x2fea1f,_0x4f8455,_0x4effcb){var _0xf296d=_0x223f42;if(!_0x4effcb['data_confirmacao'])return _0xf296d(0xce);var _0x9e81ef=new Date(_0x4effcb['data_confirmacao']);return _0x9e81ef[_0xf296d(0xd9)]()+'-'+('0'+(_0x9e81ef[_0xf296d(0x10a)]()+0x1))[_0xf296d(0xee)](-0x2)+'-'+('0'+_0x9e81ef[_0xf296d(0xc1)]())[_0xf296d(0xee)](-0x2)+'\x20'+('0'+_0x9e81ef[_0xf296d(0x104)]())[_0xf296d(0xee)](-0x2)+':'+('0'+_0x9e81ef['getMinutes']())[_0xf296d(0xee)](-0x2)+':'+('0'+_0x9e81ef[_0xf296d(0x111)]())[_0xf296d(0xee)](-0x2);}},{'data':_0x223f42(0xfa),'render':function(_0x2ccbd7,_0x154607,_0x49f7f7){return _0x2ccbd7?_0x2ccbd7:'NÃO\x20DISPONÍVEL';}},{'data':_0x223f42(0xf4)},{'data':_0x223f42(0xdc),'render':$['fn'][_0x223f42(0x100)]['render'][_0x223f42(0xe9)]('.',',',0x2,_0x223f42(0xf7))},{'data':_0x223f42(0x107),'render':$['fn']['dataTable'][_0x223f42(0xc5)][_0x223f42(0xe9)]('.',',',0x2,'R$\x20')},{'data':_0x223f42(0xdb),'render':function(_0x5e61c1,_0x1f4e34,_0x5325fe){var _0xa86c2c=_0x223f42;let _0x132ded='',_0x473a8b='';if(_0x5e61c1===0x0)_0x132ded=_0xa86c2c(0xea),_0x473a8b=_0xa86c2c(0x105);else{if(_0x5e61c1===0x1)_0x132ded='Confirmado',_0x473a8b='<button\x20class=\x22btn\x20btn-success\x20icone_tabela\x22\x20alt=\x22Confirmado\x22\x20data-toggle=\x22tooltip\x22\x20title=\x22Confirmado\x22><i\x20class=\x22ri-check-line\x22></i></button>';else _0x5e61c1===0x2?(_0x132ded=_0xa86c2c(0xfe),_0x473a8b='<button\x20class=\x22btn\x20btn-danger\x20icone_tabela\x22\x20alt=\x22Estornado\x22\x20data-toggle=\x22tooltip\x22\x20title=\x22Estornado\x22><i\x20class=\x22ri-arrow-go-back-line\x22></i></button>'):(_0x132ded='Desconhecido',_0x473a8b=_0xa86c2c(0xf8));}return'\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20style=\x22display:\x20inline-flex;\x20align-items:\x20center;\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+_0x473a8b+_0xa86c2c(0xe8)+_0x132ded+_0xa86c2c(0xf9);}},{'data':null,'orderable':![],'render':function(_0x5ac41f,_0xfe8e47,_0x4ffbe2){var _0x442f35=_0x223f42;return _0x4ffbe2['status']===0x1?_0x442f35(0xfc)+_0x4ffbe2['id']+_0x442f35(0xc3):_0x442f35(0x10e);}}],'order':[[0x1,_0x223f42(0xcb)]]}),_0x50f38f=new Date()[_0x223f42(0xe7)]()[_0x223f42(0xc4)]('T')[0x0]+_0x223f42(0xd6),_0x1d52f6=new Date()['toISOString']()['split']('T')[0x0]+_0x223f42(0x10d);_0xf676a1(_0x1d52f6,_0x50f38f),$(document)[_0x223f42(0xeb)](function(){var _0x2d7b1e=_0x223f42;$(_0x2d7b1e(0xf2))['tooltip']();});}));function _0x46f2(){var _0x326bf4=['GET','Dados\x20esperados\x20ausentes\x20na\x20resposta:','toISOString','\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span\x20style=\x22margin-left:\x208px;\x22>','number','Pendente','ready','Nenhum\x20dado\x20disponível\x20na\x20tabela','R$\x200,00','slice','setHours','8WInhYe','Processando...','[data-toggle=\x22tooltip\x22]','#tarifas-saques','descricao_cliente','Último','Carregando...','R$\x20','<span>Desconhecido</span>','</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20','endToEndId','val','\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<button\x20class=\x22btn\x20btn-primary\x20icone_tabela\x20openModal\x22\x20data-target=\x22libs/includes/comprovante?','libs/funcoes/saques/relatorio','Estornado','#total-sacado','dataTable','5MSCmuS','DataTable','Mostrar\x20_MENU_\x20registros','getHours','<button\x20class=\x22btn\x20btn-warning\x20icone_tabela\x22\x20alt=\x22Pendente\x22\x20data-toggle=\x22tooltip\x22\x20title=\x22Pendente\x22><i\x20class=\x22ri-time-line\x22></i></button>','1724706YmRnPY','taxa','data_solicitacao','load','getMonth','574639wFgZDj',':\x20Ordenar\x20colunas\x20de\x20forma\x20ascendente','\x2000:00:00','\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<button\x20class=\x22btn\x20btn-secondary\x20icone_tabela\x22\x20disabled>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<i\x20class=\x22ri-printer-line\x22></i>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</button>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20','libs/funcoes/usuario/saidas_periodo','(Filtrado\x20de\x20_MAX_\x20total\x20de\x20registros)','getSeconds','67046GWohrJ','totalSaidasPix','getDate','29818HFsrSG','\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<i\x20class=\x22ri-printer-line\x22></i>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</button>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20','split','render','map','toLocaleString',':\x20Ordenar\x20colunas\x20de\x20forma\x20descendente','Y-m-d','Primeiro','desc','Pesquisar...','\x20to\x20','NÃO\x20DISPONÍVEL','#daterange','#file-export','669170dOxdbM','Próximo','Mostrando\x200\x20até\x200\x20de\x200\x20registros','quantidadeSaques','ajax','\x2023:59:59','totalTaxasSaidas','#ticket-medio','getFullYear','libs/funcoes/saques/relatorio?data_inicial=','status','valor','flatpickr','&data_final=','1598358nMaLEX','72EGNsjb','range','getMinutes','text','647400SIOwxr'];_0x46f2=function(){return _0x326bf4;};return _0x46f2();}

    </script>

    <script src="assets/js/custom.js"></script>

    <div class="modal fade" id="modalConteudo" tabindex="-1" aria-labelledby="modalConteudo" data-bs-backdrop="static" data-bs-keyboard="false" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content">
        </div>
    </div>
</div>
<script>
    var _0x2da22d=_0x43dd;function _0x43dd(_0x56f9cd,_0x12ffb3){var _0x279609=_0x2796();return _0x43dd=function(_0x43dd32,_0x5efa92){_0x43dd32=_0x43dd32-0x1ee;var _0x26287d=_0x279609[_0x43dd32];return _0x26287d;},_0x43dd(_0x56f9cd,_0x12ffb3);}(function(_0x53f273,_0x472975){var _0x189c53=_0x43dd,_0x59a741=_0x53f273();while(!![]){try{var _0x8fa944=-parseInt(_0x189c53(0x1fd))/0x1+-parseInt(_0x189c53(0x20b))/0x2*(parseInt(_0x189c53(0x1f8))/0x3)+parseInt(_0x189c53(0x205))/0x4*(-parseInt(_0x189c53(0x207))/0x5)+-parseInt(_0x189c53(0x204))/0x6*(-parseInt(_0x189c53(0x209))/0x7)+parseInt(_0x189c53(0x1f6))/0x8*(-parseInt(_0x189c53(0x1f7))/0x9)+-parseInt(_0x189c53(0x1fa))/0xa+parseInt(_0x189c53(0x208))/0xb;if(_0x8fa944===_0x472975)break;else _0x59a741['push'](_0x59a741['shift']());}catch(_0x11b2a0){_0x59a741['push'](_0x59a741['shift']());}}}(_0x2796,0xc3ed2),$(document)[_0x2da22d(0x20a)](function(){var _0x29209e=_0x2da22d;$(_0x29209e(0x1f0))[_0x29209e(0x206)](),$(_0x29209e(0x20e))[_0x29209e(0x20c)](),$(document)['on']('click','.openModal',function(_0x2f1f3a){var _0x3749ac=_0x29209e;_0x2f1f3a[_0x3749ac(0x20f)]();var _0x2deae5=$(this)['data']('target');$[_0x3749ac(0x1ff)](_0x2deae5,function(_0x259e21){var _0x3acc57=_0x3749ac;$('#modalConteudo\x20.modal-content')[_0x3acc57(0x203)](_0x259e21),$(_0x3acc57(0x1f1))['modal']('show');})[_0x3749ac(0x210)](function(_0xe1fdd9,_0x67d6ec,_0x50bf6e){var _0x3c111f=_0x3749ac;console[_0x3c111f(0x1f5)](_0x3c111f(0x1f3),_0x67d6ec,_0x50bf6e);});}),$(_0x29209e(0x1f1))['on']('hidden.bs.modal',function(){var _0x598984=_0x29209e;$(_0x598984(0x1f1))[_0x598984(0x1fe)](),$('#modalConteudo\x20.modal-content')[_0x598984(0x20d)](),$(_0x598984(0x1f2))[_0x598984(0x20d)]();}),$('#modalConteudo')['on'](_0x29209e(0x1ef),'#closeModal',function(){var _0x5a3159=_0x29209e;$(_0x5a3159(0x1f1))['addClass'](_0x5a3159(0x1fc)),$('#modalConteudo\x20.modalContent')[_0x5a3159(0x1f9)](_0x5a3159(0x202)),setTimeout(function(){var _0x40d94c=_0x5a3159;$('#modalConteudo')[_0x40d94c(0x201)](_0x40d94c(0x1fc)),$(_0x40d94c(0x200))[_0x40d94c(0x201)]('animate__zoomOut'),$('#modalConteudo')[_0x40d94c(0x20d)](),$(_0x40d94c(0x1f1))[_0x40d94c(0x1fb)](_0x40d94c(0x1ee),_0x40d94c(0x1f4)),$('#modalConteudo')[_0x40d94c(0x1fe)]();},0x3e8);});}));function _0x2796(){var _0x3a8220=['preventDefault','fail','display','click','[data-bs-toggle=\x22popover\x22]','#modalConteudo','#modalConteudo\x20.modal-footer','Erro\x20ao\x20carregar\x20o\x20modal:','none','error','1646632njQbrG','9WzWKMo','7644bcfCdN','addClass','8280060LwmgxF','css','animate__fadeOut','1039560bOSkeh','off','get','#modalConteudo\x20.modalContent','removeClass','animate__zoomOut','html','114rtdizd','4YvauSn','popover','5387870xAaISk','34490346dmfNQY','573601tDjsSF','ready','580ZzmsdV','tooltip','empty','[data-bs-toggle=\x22tooltip\x22]'];_0x2796=function(){return _0x3a8220;};return _0x2796();}
</script>
    <style>
    .toast-container {
        position: fixed;
        top: 25px;
        right: 30px;
        display: flex;
        flex-direction: column;
        gap: 10px;
    }
    .toast {
        position: relative;
        border-radius: 6px;
        background: #fff;
        padding: 20px 35px 20px 25px;
        box-shadow: 0 5px 10px rgba(0, 0, 0, 0.1);
        border-left: 8px solid rgb(0, 203, 161);
        overflow: hidden;
        transform: translateX(calc(100% + 30px));
        transition: all 0.5s cubic-bezier(0.68, -0.55, 0.25, 1.35);
        display: block !important;
    }
    .toast.active {
        transform: translateX(0);
    }
    .toast-content {
        display: flex;
        align-items: center;
    }
    .toast-check {
        display: flex;
        justify-content: center;
        align-items: center;
        background-color: rgb(0, 203, 161);
        border-radius: 50%;
        color: #fff;
        font-size: 20px;
        width: 40px;
        height: 40px;
    }
    .message {
        display: flex;
        flex-direction: column;
        margin: 0 16px;
    }
    .message-text {
        font-size: 20px;
        font-weight: 600;
    }
    .text-1 {
        color: #333;
    }
    .text-2 {
        color: #666;
        font-weight: 400;
        font-size: 16px;
    }
    .toast-close {
        position: absolute;
        top: 10px;
        right: 15px;
        padding: 5px;
        cursor: pointer;
        opacity: 0.7;
        color: #00cba1;
    }
    .toast-close:hover {
        opacity: 1;
    }
    .progress {
        position: absolute;
        bottom: 0;
        left: 0;
        height: 3px;
        width: 100%;
        background: #ddd;
    }
    .progress::before {
        content: "";
        position: absolute;
        bottom: 0;
        right: 0;
        height: 100%;
        width: 100%;
        background-color: rgb(0, 203, 161);
    }
    .progress.active::before {
        animation: progress 5s linear forwards;
    }
    @keyframes progress {
        100% {
            right: 100%;
        }
    }
    .toast-btn {
        padding: 10px 40px;
        font-size: 20px;
        outline: none;
        border: none;
        background-color: #40f467;
        color: #fff;
        border-radius: 50px;
        cursor: pointer;
        transition: 0.3s;
    }
    .toast-btn:hover {
        background-color: #0fbd35;
    }
</style>
<div class="toast-container"></div>
<script>
    function _0x553b(_0x2e5c0a,_0x2e7c71){const _0x5d8a02=_0x5d8a();return _0x553b=function(_0x553b9c,_0x101e05){_0x553b9c=_0x553b9c-0x158;let _0x3fb95a=_0x5d8a02[_0x553b9c];return _0x3fb95a;},_0x553b(_0x2e5c0a,_0x2e7c71);}function _0x5d8a(){const _0x1c32f9=['4314338dyFgoH','remove','find','active','47jOpOel','append','6AlcdiJ','1704916uZVurw','110BcUHGs','1037570sCalrz','getTime','\x20toast-check\x22></i>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22message\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span\x20class=\x22message-text\x20text-1\x22>','\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22toast-content\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22icon\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<i\x20class=\x22','8ijGyDq','toast-','7511463lahDnG','.toast-close','\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22toast\x22\x20id=\x22','10992TjaZtH','30563SETBHB','</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span\x20class=\x22message-text\x20text-2\x22>','5GqijzQ','971916BieQyK','removeClass','.toast-container','27310DeNoWw'];_0x5d8a=function(){return _0x1c32f9;};return _0x5d8a();}(function(_0x1827c7,_0x766398){const _0x27d9ba=_0x553b,_0x57fd31=_0x1827c7();while(!![]){try{const _0x31012d=-parseInt(_0x27d9ba(0x160))/0x1*(parseInt(_0x27d9ba(0x15b))/0x2)+parseInt(_0x27d9ba(0x158))/0x3+parseInt(_0x27d9ba(0x163))/0x4*(-parseInt(_0x27d9ba(0x171))/0x5)+-parseInt(_0x27d9ba(0x162))/0x6*(parseInt(_0x27d9ba(0x15c))/0x7)+-parseInt(_0x27d9ba(0x169))/0x8*(-parseInt(_0x27d9ba(0x16b))/0x9)+parseInt(_0x27d9ba(0x165))/0xa*(-parseInt(_0x27d9ba(0x164))/0xb)+-parseInt(_0x27d9ba(0x16e))/0xc*(-parseInt(_0x27d9ba(0x16f))/0xd);if(_0x31012d===_0x766398)break;else _0x57fd31['push'](_0x57fd31['shift']());}catch(_0x30c173){_0x57fd31['push'](_0x57fd31['shift']());}}}(_0x5d8a,0x90161));function showToast(_0x2ba221,_0x1db0d4,_0x151283){const _0x540b48=_0x553b,_0x4bea7d=_0x540b48(0x16a)+new Date()[_0x540b48(0x166)](),_0x1f58ce=_0x540b48(0x16d)+_0x4bea7d+_0x540b48(0x168)+_0x2ba221+_0x540b48(0x167)+_0x1db0d4+_0x540b48(0x170)+_0x151283+'</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<i\x20class=\x22bi\x20bi-x\x20toast-close\x22></i>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22progress\x22></div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20';$(_0x540b48(0x15a))[_0x540b48(0x161)](_0x1f58ce);const _0x32f9f3=$('#'+_0x4bea7d);setTimeout(()=>{const _0x1c9b36=_0x540b48;_0x32f9f3['addClass'](_0x1c9b36(0x15f)),_0x32f9f3['find']('.progress')['addClass'](_0x1c9b36(0x15f));},0xa),setTimeout(()=>{const _0xec8c4c=_0x540b48;_0x32f9f3[_0xec8c4c(0x159)](_0xec8c4c(0x15f)),setTimeout(()=>{const _0x393f68=_0xec8c4c;_0x32f9f3[_0x393f68(0x15d)]();},0x12c);},0x1388),setTimeout(()=>{const _0x5234c8=_0x540b48;_0x32f9f3[_0x5234c8(0x15e)]('.progress')['removeClass'](_0x5234c8(0x15f));},0x14b4),_0x32f9f3[_0x540b48(0x15e)](_0x540b48(0x16c))['on']('click',function(){const _0x2e35df=_0x540b48;_0x32f9f3[_0x2e35df(0x159)](_0x2e35df(0x15f)),setTimeout(()=>{const _0x3962c9=_0x2e35df;_0x32f9f3[_0x3962c9(0x15d)]();},0x12c);});}
</script>
</body>

</html>