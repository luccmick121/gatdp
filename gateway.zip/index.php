<?php
session_start();

include('libs/updateUserInfo.php');

if (!isset($_SESSION['user_id'])) {
    header("Location: /login");
    exit();
}
if (isset($_SESSION['documents_checked'])) {
    if($_SESSION['documents_checked'] == 0) {
        header("Location: /settings");
        exit();
    }
}
?>
<!DOCTYPE html>

<html lang="pt-br" dir="ltr" data-nav-layout="vertical" data-theme-mode="light" data-header-styles="light" data-menu-styles="light" data-toggled="close">



<head>



    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <title> <?php include 'libs/get_site_name.php'; ?> - Início </title>

    <meta name="Description" content="Dashboard principal do gateway de pagamento <?php include 'libs/get_site_name.php'; ?>">

    <meta name="Author" content="Ellodev">

	<meta name="keywords" content="Gateway de pagamento">

    

    <!-- Favicon -->

    <link rel="icon" href="<?php include 'libs/get_site_favicon.php'; ?>" type="image/x-icon">

    

    <!-- Choices JS -->

    <script src="assets/libs/choices.js/public/assets/scripts/choices.min.js"></script>



    <!-- Main Theme Js -->

    <script src="assets/js/main.js"></script>

    

    <!-- Bootstrap Css -->

    <link id="style" href="assets/libs/bootstrap/css/bootstrap.min.css" rel="stylesheet" >



    <!-- Style Css -->

    <?php include 'libs/config_css.php'; ?>



    <!-- Icons Css -->

    <link href="assets/css/icons.css" rel="stylesheet" >



    <!-- Node Waves Css -->

    <link href="assets/libs/node-waves/waves.min.css" rel="stylesheet" > 



    <!-- Simplebar Css -->

    <link href="assets/libs/simplebar/simplebar.min.css" rel="stylesheet" >

    

    <!-- Color Picker Css -->

    <link rel="stylesheet" href="assets/libs/flatpickr/flatpickr.min.css">

    <link rel="stylesheet" href="assets/libs/@simonwep/pickr/themes/nano.min.css">



    <!-- Choices Css -->

    <link rel="stylesheet" href="assets/libs/choices.js/public/assets/styles/choices.min.css">


    <?php
    try {
        // Definir variáveis de conexão
        $dbHost = $_ENV['DB_HOST'];
        $dbnome = $_ENV['DB_NAME'];
        $dbUser = $_ENV['DB_USER'];
        $dbPass = $_ENV['DB_PASS'];

        // Conectar ao banco de dados
        $dsn = "mysql:host=$dbHost;dbname=$dbnome;charset=utf8";
        $pdo = new PDO($dsn, $dbUser, $dbPass);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Consultar as cores RGB armazenadas no banco de dados
        $query = "SELECT primary_color, secondary_color FROM config LIMIT 1"; // Supondo que as cores estejam na tabela config
        $stmt = $pdo->prepare($query);
        $stmt->execute();
        $config = $stmt->fetch(PDO::FETCH_ASSOC);

        // Obter as cores RGB do banco, caso não existam, usar valores padrão
        $primaryRgb = isset($config['primary_color']) ? $config['primary_color'] : '0, 203, 161'; // Exemplo de RGB padrão
        $secondaryRgb = isset($config['secondary_color']) ? $config['secondary_color'] : '69, 214, 91'; // Exemplo de RGB padrão
    } catch (PDOException $e) {
        die("Erro ao conectar ao banco de dados: " . $e->getMessage());
    }
    ?>

    <style>
        :root {
            --primary-rgb: <?php echo $primaryRgb; ?>;
            --secondary-rgb: <?php echo $secondaryRgb; ?>;
            --success-rgb: <?php echo $primaryRgb; ?>;
        }

        .box_code {
            padding-inline: 0;
            border: 1px solid rgb(<?php echo $primaryRgb; ?>);
            width: 39px;
            height: 39px;
            margin: 0px 4px;
            border-radius: 10px;
        }
    </style>

</head>

<body>

<div id="loader">

    <img src="assets/images/media/loader.svg" alt="">

</div>

<div class="page">

        <!-- Start Switcher -->
    <div class="offcanvas offcanvas-end" tabindex="-1" id="switcher-canvas" aria-labelledby="offcanvasRightLabel">
    <div class="offcanvas-body">
        <div class="tab-content" id="nav-tabContent">
            <div class="tab-pane fade show active border-0" id="switcher-home" role="tabpanel" aria-labelledby="switcher-home-tab"
                tabindex="0">
                <div class="">
                    <p class="switcher-style-head">Theme Color Mode:</p>
                    <div class="row switcher-style gx-0">
                        <div class="col-4">
                            <div class="form-check switch-select">
                                <label class="form-check-label" for="switcher-light-theme">
                                    Light
                                </label>
                                <input class="form-check-input" type="radio" name="theme-style" id="switcher-light-theme"
                                    checked>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="form-check switch-select">
                                <label class="form-check-label" for="switcher-dark-theme">
                                    Dark
                                </label>
                                <input class="form-check-input" type="radio" name="theme-style" id="switcher-dark-theme">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="">
                    <p class="switcher-style-head">Directions:</p>
                    <div class="row switcher-style gx-0">
                        <div class="col-4">
                            <div class="form-check switch-select">
                                <label class="form-check-label" for="switcher-ltr">
                                    LTR
                                </label>
                                <input class="form-check-input" type="radio" name="direction" id="switcher-ltr" checked>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="form-check switch-select">
                                <label class="form-check-label" for="switcher-rtl">
                                    RTL
                                </label>
                                <input class="form-check-input" type="radio" name="direction" id="switcher-rtl">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="">
                    <p class="switcher-style-head">Navigation Styles:</p>
                    <div class="row switcher-style gx-0">
                        <div class="col-4">
                            <div class="form-check switch-select">
                                <label class="form-check-label" for="switcher-vertical">
                                    Vertical
                                </label>
                                <input class="form-check-input" type="radio" name="navigation-style" id="switcher-vertical"
                                    checked>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="form-check switch-select">
                                <label class="form-check-label" for="switcher-horizontal">
                                    Horizontal
                                </label>
                                <input class="form-check-input" type="radio" name="navigation-style"
                                    id="switcher-horizontal">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="navigation-menu-styles">
                    <p class="switcher-style-head">Vertical & Horizontal Menu Styles:</p>
                    <div class="row switcher-style gx-0 pb-2 gy-2">
                        <div class="col-4">
                            <div class="form-check switch-select">
                                <label class="form-check-label" for="switcher-menu-click">
                                    Menu Click
                                </label>
                                <input class="form-check-input" type="radio" name="navigation-menu-styles"
                                    id="switcher-menu-click">
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="form-check switch-select">
                                <label class="form-check-label" for="switcher-menu-hover">
                                    Menu Hover
                                </label>
                                <input class="form-check-input" type="radio" name="navigation-menu-styles"
                                    id="switcher-menu-hover">
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="form-check switch-select">
                                <label class="form-check-label" for="switcher-icon-click">
                                    Icon Click
                                </label>
                                <input class="form-check-input" type="radio" name="navigation-menu-styles"
                                    id="switcher-icon-click">
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="form-check switch-select">
                                <label class="form-check-label" for="switcher-icon-hover">
                                    Icon Hover
                                </label>
                                <input class="form-check-input" type="radio" name="navigation-menu-styles"
                                    id="switcher-icon-hover">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="sidemenu-layout-styles">
                    <p class="switcher-style-head">Sidemenu Layout Styles:</p>
                    <div class="row switcher-style gx-0 pb-2 gy-2">
                        <div class="col-sm-6">
                            <div class="form-check switch-select">
                                <label class="form-check-label" for="switcher-default-menu">
                                    Default Menu
                                </label>
                                <input class="form-check-input" type="radio" name="sidemenu-layout-styles"
                                    id="switcher-default-menu" checked>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-check switch-select">
                                <label class="form-check-label" for="switcher-closed-menu">
                                    Closed Menu
                                </label>
                                <input class="form-check-input" type="radio" name="sidemenu-layout-styles"
                                    id="switcher-closed-menu">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-check switch-select">
                                <label class="form-check-label" for="switcher-icontext-menu">
                                    Icon Text
                                </label>
                                <input class="form-check-input" type="radio" name="sidemenu-layout-styles"
                                    id="switcher-icontext-menu">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-check switch-select">
                                <label class="form-check-label" for="switcher-icon-overlay">
                                    Icon Overlay
                                </label>
                                <input class="form-check-input" type="radio" name="sidemenu-layout-styles"
                                    id="switcher-icon-overlay">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-check switch-select">
                                <label class="form-check-label" for="switcher-detached">
                                    Detached
                                </label>
                                <input class="form-check-input" type="radio" name="sidemenu-layout-styles"
                                    id="switcher-detached">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-check switch-select">
                                <label class="form-check-label" for="switcher-double-menu">
                                    Double Menu
                                </label>
                                <input class="form-check-input" type="radio" name="sidemenu-layout-styles"
                                    id="switcher-double-menu">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="">
                    <p class="switcher-style-head">Page Styles:</p>
                    <div class="row switcher-style gx-0">
                        <div class="col-4">
                            <div class="form-check switch-select">
                                <label class="form-check-label" for="switcher-regular">
                                    Regular
                                </label>
                                <input class="form-check-input" type="radio" name="page-styles" id="switcher-regular"
                                    checked>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="form-check switch-select">
                                <label class="form-check-label" for="switcher-classic">
                                    Classic
                                </label>
                                <input class="form-check-input" type="radio" name="page-styles" id="switcher-classic">
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="form-check switch-select">
                                <label class="form-check-label" for="switcher-modern">
                                    Modern
                                </label>
                                <input class="form-check-input" type="radio" name="page-styles" id="switcher-modern">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="">
                    <p class="switcher-style-head">Layout Width Styles:</p>
                    <div class="row switcher-style gx-0">
                        <div class="col-4">
                            <div class="form-check switch-select">
                                <label class="form-check-label" for="switcher-full-width">
                                    Full Width
                                </label>
                                <input class="form-check-input" type="radio" name="layout-width" id="switcher-full-width"
                                    checked>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="form-check switch-select">
                                <label class="form-check-label" for="switcher-boxed">
                                    Boxed
                                </label>
                                <input class="form-check-input" type="radio" name="layout-width" id="switcher-boxed">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="">
                    <p class="switcher-style-head">Menu Positions:</p>
                    <div class="row switcher-style gx-0">
                        <div class="col-4">
                            <div class="form-check switch-select">
                                <label class="form-check-label" for="switcher-menu-fixed">
                                    Fixed
                                </label>
                                <input class="form-check-input" type="radio" name="menu-positions" id="switcher-menu-fixed"
                                    checked>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="form-check switch-select">
                                <label class="form-check-label" for="switcher-menu-scroll">
                                    Scrollable
                                </label>
                                <input class="form-check-input" type="radio" name="menu-positions" id="switcher-menu-scroll">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="">
                    <p class="switcher-style-head">Header Positions:</p>
                    <div class="row switcher-style gx-0">
                        <div class="col-4">
                            <div class="form-check switch-select">
                                <label class="form-check-label" for="switcher-header-fixed">
                                    Fixed
                                </label>
                                <input class="form-check-input" type="radio" name="header-positions"
                                    id="switcher-header-fixed" checked>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="form-check switch-select">
                                <label class="form-check-label" for="switcher-header-scroll">
                                    Scrollable
                                </label>
                                <input class="form-check-input" type="radio" name="header-positions"
                                    id="switcher-header-scroll">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="">
                    <p class="switcher-style-head">Loader:</p>
                    <div class="row switcher-style gx-0">
                        <div class="col-4">
                            <div class="form-check switch-select">
                                <label class="form-check-label" for="switcher-loader-enable">
                                    Enable
                                </label>
                                <input class="form-check-input" type="radio" name="page-loader"
                                    id="switcher-loader-enable">
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="form-check switch-select">
                                <label class="form-check-label" for="switcher-loader-disable">
                                    Disable
                                </label>
                                <input class="form-check-input" type="radio" name="page-loader"
                                    id="switcher-loader-disable" checked>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="tab-pane fade border-0" id="switcher-profile" role="tabpanel" aria-labelledby="switcher-profile-tab" tabindex="0">
                <div>
                    <div class="theme-colors">
                        <p class="switcher-style-head">Menu Colors:</p>
                        <div class="d-flex switcher-style pb-2">
                            <div class="form-check switch-select me-3">
                                <input class="form-check-input color-input color-white" data-bs-toggle="tooltip"
                                    data-bs-placement="top" title="Light Menu" type="radio" name="menu-colors"
                                    id="switcher-menu-light" checked>
                            </div>
                            <div class="form-check switch-select me-3">
                                <input class="form-check-input color-input color-dark" data-bs-toggle="tooltip"
                                    data-bs-placement="top" title="Dark Menu" type="radio" name="menu-colors"
                                    id="switcher-menu-dark">
                            </div>
                            <div class="form-check switch-select me-3">
                                <input class="form-check-input color-input color-primary" data-bs-toggle="tooltip"
                                    data-bs-placement="top" title="Color Menu" type="radio" name="menu-colors"
                                    id="switcher-menu-primary">
                            </div>
                            <div class="form-check switch-select me-3">
                                <input class="form-check-input color-input color-gradient" data-bs-toggle="tooltip"
                                    data-bs-placement="top" title="Gradient Menu" type="radio" name="menu-colors"
                                    id="switcher-menu-gradient">
                            </div>
                            <div class="form-check switch-select me-3">
                                <input class="form-check-input color-input color-transparent"
                                    data-bs-toggle="tooltip" data-bs-placement="top" title="Transparent Menu"
                                    type="radio" name="menu-colors" id="switcher-menu-transparent">
                            </div>
                        </div>
                        <div class="px-4 pb-3 text-muted fs-11">Note:If you want to change color Menu dynamically change from below Theme Primary color picker</div>
                    </div>
                    <div class="theme-colors">
                        <p class="switcher-style-head">Header Colors:</p>
                        <div class="d-flex switcher-style pb-2">
                            <div class="form-check switch-select me-3">
                                <input class="form-check-input color-input color-white" data-bs-toggle="tooltip"
                                    data-bs-placement="top" title="Light Header" type="radio" name="header-colors"
                                    id="switcher-header-light" checked>
                            </div>
                            <div class="form-check switch-select me-3">
                                <input class="form-check-input color-input color-dark" data-bs-toggle="tooltip"
                                    data-bs-placement="top" title="Dark Header" type="radio" name="header-colors"
                                    id="switcher-header-dark">
                            </div>
                            <div class="form-check switch-select me-3">
                                <input class="form-check-input color-input color-primary" data-bs-toggle="tooltip"
                                    data-bs-placement="top" title="Color Header" type="radio" name="header-colors"
                                    id="switcher-header-primary">
                            </div>
                            <div class="form-check switch-select me-3">
                                <input class="form-check-input color-input color-gradient" data-bs-toggle="tooltip"
                                    data-bs-placement="top" title="Gradient Header" type="radio" name="header-colors"
                                    id="switcher-header-gradient">
                            </div>
                            <div class="form-check switch-select me-3">
                                <input class="form-check-input color-input color-transparent" data-bs-toggle="tooltip"
                                    data-bs-placement="top" title="Transparent Header" type="radio" name="header-colors"
                                    id="switcher-header-transparent">
                            </div>
                        </div>
                        <div class="px-4 pb-3 text-muted fs-11">Note:If you want to change color Header dynamically change from below Theme Primary color picker</div>
                    </div>
                    <div class="theme-colors">
                        <p class="switcher-style-head">Theme Primary:</p>
                        <div class="d-flex flex-wrap align-items-center switcher-style">
                            <div class="form-check switch-select me-3">
                                <input class="form-check-input color-input color-primary-1" type="radio"
                                    name="theme-primary" id="switcher-primary">
                            </div>
                            <div class="form-check switch-select me-3">
                                <input class="form-check-input color-input color-primary-2" type="radio"
                                    name="theme-primary" id="switcher-primary1">
                            </div>
                            <div class="form-check switch-select me-3">
                                <input class="form-check-input color-input color-primary-3" type="radio" name="theme-primary"
                                    id="switcher-primary2">
                            </div>
                            <div class="form-check switch-select me-3">
                                <input class="form-check-input color-input color-primary-4" type="radio" name="theme-primary"
                                    id="switcher-primary3">
                            </div>
                            <div class="form-check switch-select me-3">
                                <input class="form-check-input color-input color-primary-5" type="radio" name="theme-primary"
                                    id="switcher-primary4">
                            </div>
                            <div class="form-check switch-select ps-0 mt-1 color-primary-light">
                                <div class="theme-container-primary"></div>
                                <div class="pickr-container-primary"  onchange="updateChartColor(this.value)"></div>
                            </div>
                        </div>
                    </div>
                    <div class="theme-colors">
                        <p class="switcher-style-head">Theme Background:</p>
                        <div class="d-flex flex-wrap align-items-center switcher-style">
                            <div class="form-check switch-select me-3">
                                <input class="form-check-input color-input color-bg-1" type="radio"
                                    name="theme-background" id="switcher-background">
                            </div>
                            <div class="form-check switch-select me-3">
                                <input class="form-check-input color-input color-bg-2" type="radio"
                                    name="theme-background" id="switcher-background1">
                            </div>
                            <div class="form-check switch-select me-3">
                                <input class="form-check-input color-input color-bg-3" type="radio" name="theme-background"
                                    id="switcher-background2">
                            </div>
                            <div class="form-check switch-select me-3">
                                <input class="form-check-input color-input color-bg-4" type="radio"
                                    name="theme-background" id="switcher-background3">
                            </div>
                            <div class="form-check switch-select me-3">
                                <input class="form-check-input color-input color-bg-5" type="radio"
                                    name="theme-background" id="switcher-background4">
                            </div>
                            <div class="form-check switch-select ps-0 mt-1 tooltip-static-demo color-bg-transparent">
                                <div class="theme-container-background"></div>
                                <div class="pickr-container-background"></div>
                            </div>
                        </div>
                    </div>
                    <div class="menu-image mb-3">
                        <p class="switcher-style-head">Menu With Background Image:</p>
                        <div class="d-flex flex-wrap align-items-center switcher-style">
                            <div class="form-check switch-select m-2">
                                <input class="form-check-input bgimage-input bg-img1" type="radio"
                                    name="theme-background" id="switcher-bg-img">
                            </div>
                            <div class="form-check switch-select m-2">
                                <input class="form-check-input bgimage-input bg-img2" type="radio"
                                    name="theme-background" id="switcher-bg-img1">
                            </div>
                            <div class="form-check switch-select m-2">
                                <input class="form-check-input bgimage-input bg-img3" type="radio" name="theme-background"
                                    id="switcher-bg-img2">
                            </div>
                            <div class="form-check switch-select m-2">
                                <input class="form-check-input bgimage-input bg-img4" type="radio"
                                    name="theme-background" id="switcher-bg-img3">
                            </div>
                            <div class="form-check switch-select m-2">
                                <input class="form-check-input bgimage-input bg-img5" type="radio"
                                    name="theme-background" id="switcher-bg-img4">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="d-flex justify-content-center canvas-footer flex-wrap">
                <a href="javascript:void(0);" id="reset-all" class="btn btn-danger m-1 w-100">Reset</a> 
            </div>
        </div>
    </div>
</div>
<header class="app-header">
    <div class="main-header-container container-fluid">
        <div class="header-content-left">
            <div class="header-element">
                <div class="horizontal-logo">
                    <a href="./" class="header-logo">
                        <img src="<?php include 'libs/get_site_logo.php'; ?>" alt="logo" class="desktop-logo">
                        <img src="<?php include 'libs/get_site_toggle_logo.php'; ?>" alt="logo" class="toggle-logo">
                        <img src="<?php include 'libs/get_site_logo.php'; ?>" alt="logo" class="desktop-dark">
                        <img src="<?php include 'libs/get_site_toggle_logo.php'; ?>" alt="logo" class="toggle-dark">
                    </a>
                </div>
            </div>
            <div class="header-element mx-lg-0 mx-2 sidemenu-toggle" data-bs-toggle="sidebar">
                <a aria-label="Hide Sidebar" class="header-link animated-arrow hor-toggle horizontal-navtoggle"><span></span></a>
            </div>
        </div>
        <ul class="header-content-right">
            <li class="header-element header-theme-mode">
                <a href="javascript:void(0);" class="header-link layout-setting">
                    <span class="light-layout">
                        <i class="bi bi-moon header-link-icon"></i>
                    </span>
                    <span class="dark-layout">
                        <i class="bi bi-brightness-high header-link-icon"></i>
                    </span>
                </a>
            </li>
            <li class="header-element notifications-dropdown d-xl-block d-none">
                <a href="javascript:void(0);" class="header-link dropdown-toggle" data-bs-toggle="dropdown" data-bs-auto-close="outside" id="messageDropdown" aria-expanded="false">
                    <i class="bi bi-bell header-link-icon"></i>
                    <span class="header-icon-pulse bg-secondary rounded pulse pulse-secondary"></span>
                </a>
                <div class="main-header-dropdown dropdown-menu dropdown-menu-end" data-popper-placement="none">
                    <div class="p-3">
                        <div class="d-flex align-items-center justify-content-between">
                            <p class="mb-0 fs-16">Notificações</p>
                            <span class="badge bg-secondary-transparent d-none" id="notifiation-data">0 Notificações</span>
                        </div>
                    </div>
                    <div class="dropdown-divider"></div>
                    <div class="p-5 empty-item1">
                        <div class="text-center">
                            <span class="avatar avatar-xl avatar-rounded bg-secondary-transparent">
                                <i class="ri-notification-off-line fs-2"></i>
                            </span>
                            <h6 class="fw-medium mt-3">Não existem notificações</h6>
                        </div>
                    </div>
                </div>
            </li>
            <li class="header-element">
                <a href="javascript:void(0);" class="header-link dropdown-toggle" id="mainHeaderProfile" data-bs-toggle="dropdown" data-bs-auto-close="outside" aria-expanded="false">
                    <i class="ri-user-line header-link-icon"></i>
                </a>
                <ul class="main-header-dropdown dropdown-menu pt-0 overflow-hidden header-profile-dropdown dropdown-menu-end" aria-labelledby="mainHeaderProfile">
                    <li><a class="dropdown-item d-flex align-items-center" href="profile"><i class="bi bi-person fs-18 me-2 op-7"></i>Perfil</a></li>
                    <li><a class="dropdown-item d-flex align-items-center" href="logout"><i class="bi bi-box-arrow-right fs-18 me-2 op-7"></i>Sair</a></li>
                </ul>
            </li>  
        </ul>
    </div>
</header>

    <aside class="app-sidebar sticky" id="sidebar">
    <div class="main-sidebar-header">
        <a href="./" class="header-logo d-flex align-items-center">
            <div>
                <img src="<?php include 'libs/get_site_logo.php'; ?>" alt="logo" class="desktop-logo">
                <img src="<?php include 'libs/get_site_toggle_logo.php'; ?>" alt="logo" class="toggle-dark mini_logo">
                <img src="<?php include 'libs/get_site_logo.php'; ?>" alt="logo" class="desktop-dark">
                <img src="<?php include 'libs/get_site_toggle_logo.php'; ?>" alt="logo" class="toggle-logo mini_logo">
            </div>
            <?php include 'libs/check_pay_logo.php'; ?>
        </a>
    </div>
    <div class="main-sidebar" id="sidebar-scroll">
        <nav class="main-menu-container nav nav-pills flex-column sub-open">
            <div class="slide-left" id="slide-left">
                <svg xmlns="http://www.w3.org/2000/svg" fill="#7b8191" width="24" height="24" viewBox="0 0 24 24"> <path d="M13.293 6.293 7.586 12l5.707 5.707 1.414-1.414L10.414 12l4.293-4.293z"></path> </svg>
            </div>
            <ul class="main-menu">
                <li class="slide">
                    <a href="./" class="side-menu__item">
                        <i class="bi bi-house side-menu__icon"></i>
                        <span class="side-menu__label">Dashboard</span>
                    </a>
                </li>
                <li class="slide">
                    <a class="side-menu__item openModal" data-target="libs/includes/falar_gerente">
                        <i class="ri-customer-service-2-fill side-menu__icon"></i>
                        <span class="side-menu__label">Fale com seu Gerente</span>
                    </a>
                </li>
                
                        

                <?php
                            if(isset($_SESSION['documents_checked']) && $_SESSION['documents_checked'] == 1) {
                                ?>
                            <li class="slide has-sub">
                                <a href="javascript:void(0);" class="side-menu__item">
                                    <i class="bi bi-arrow-down-up side-menu__icon"></i>
                                    <span class="side-menu__label">Transferências</span>
                                    <i class="fe fe-chevron-right side-menu__angle"></i>
                                </a>
                                <ul class="slide-menu child1 pages-ul">
                                    <li class="slide side-menu__label1">
                                        <a href="javascript:void(0)">Transferências</a>
                                    </li>
                                    <li class="slide">
                                        <a data-target="libs/includes/gerar_pix" class="side-menu__item openModal">Receber via Pix</a>
                                    </li>
                                    <li class="slide">
                                        <a data-target="libs/includes/gerar_saque" class="side-menu__item openModal">Transferir via Pix</a>
                                    </li>
                                    <li class="slide">
                                        <a data-target="libs/includes/transferencia_interna" class="side-menu__item openModal">Transferência Interna</a>
                                    </li>
                                </ul>
                            </li>
                            <li class="slide has-sub">
                                <a href="javascript:void(0);" class="side-menu__item">
                                    <i class="bi bi-graph-up side-menu__icon"></i>
                                    <span class="side-menu__label">Relatórios</span>
                                    <i class="fe fe-chevron-right side-menu__angle"></i>
                                </a>
                                <ul class="slide-menu child1 pages-ul">
                                    <li class="slide side-menu__label1">
                                        <a href="javascript:void(0)">Relatórios</a>
                                    </li>
                                    <li class="slide">
                                        <a href="cashin" class="side-menu__item">Entradas PIX</a>
                                    </li>
                                    <li class="slide">
                                        <a href="cashout" class="side-menu__item">Saídas PIX</a>
                                    </li>
                                    <li class="slide">
                                        <a href="internal_transfer" class="side-menu__item">Transferência Interna</a>
                                    </li>
                                    <!-- <li class="slide">
                                        <a href="webhooks" class="side-menu__item">Webhooks</a>
                                    </li> !-->
                                </ul>
                            </li>
                            <li class="slide has-sub">
                                <a href="javascript:void(0);" class="side-menu__item">
                                    <i class="bi bi-code-slash side-menu__icon"></i>
                                    <span class="side-menu__label">API</span>
                                    <i class="fe fe-chevron-right side-menu__angle"></i>
                                </a>
                                <ul class="slide-menu child1 pages-ul">
                                    <li class="slide side-menu__label1">
                                        <a href="javascript:void(0)">API</a>
                                    </li>
                                    <li class="slide">
                                        <a href="keys" class="side-menu__item">Credenciais</a>
                                    </li>
                                    <li class="slide">
                                        <a href="https://dev.bspay.co" target="_blank" class="side-menu__item">Documentação</a>
                                    </li>
                                </ul>
                            </li>
                            <?php
                            }
                            ?>


                                        <li class="slide">
                    <a href="settings" class="side-menu__item">
                        <i class="bi bi-gear side-menu__icon"></i>
                        <span class="side-menu__label">Configurações</span>
                    </a>
                </li>
            </ul>
            <div class="slide-right" id="slide-right"><svg xmlns="http://www.w3.org/2000/svg" fill="#7b8191" width="24" height="24" viewBox="0 0 24 24"> <path d="M10.707 17.707 16.414 12l-5.707-5.707-1.414 1.414L13.586 12l-4.293 4.293z"></path> </svg></div>
        </nav>
    </div>
</aside>
    <div class="main-content app-content">

        <div class="container-fluid">

            <div class="d-flex align-items-center justify-content-between my-4 page-header-breadcrumb flex-wrap gap-2">

                <div>

                    <p class="fw-medium fs-20 mb-0">Visão Geral</p>

                </div>

            </div>

            <div class="row">

                <div class="col-md-12 col-xl-12">

                    <div class="row">

                        <div class="col-md-6 col-lg-3 col-xl-3">

                            <div class="card custom-card overflow-hidden">

                                <div class="card-body p-0">

                                    <div class="mb-2 p-3 pb-0">

                                        <div class="flex-fill fs-15">Saldo Disponível</div>

                                    </div>

                                    <div class="d-flex flex-column ps-3">

                                        <div class="flex-fill">

                                        <div class="fs-25 fw-normal mb-2">
                                            R$ <?= str_replace('.', ',', number_format($_SESSION['balance'], 2)) ?>
                                        </div>

                                        </div>

                                        <div id="sales-card" class="crm-card-chart"></div>

                                    </div>

                                </div>

                            </div>

                        </div>

                        <?php
// Função para conectar ao banco de dados
function connectDb245() {
    // Obtendo as variáveis de ambiente para a conexão com o banco
    $dbHost = getenv('DB_HOST');
    $dbName = getenv('DB_NAME');
    $dbUser = getenv('DB_USER');
    $dbPass = getenv('DB_PASS');

    try {
        // Conexão PDO com o banco de dados
        $pdo = new PDO("mysql:host=$dbHost;dbname=$dbName", $dbUser, $dbPass);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $pdo;
    } catch (PDOException $e) {
        die("Erro ao conectar ao banco de dados: " . $e->getMessage());
    }
}

// Função para calcular o total das transações do usuário (DEPOSIT e INTERNAL_TRANSFER)
function getUserBalance($pdo, $user_id) {
    // Consulta para somar transações DEPOSIT e INTERNAL_TRANSFER com external_id igual ao user_id
    $stmt = $pdo->prepare("
        SELECT SUM(amount) AS total 
        FROM transactions 
        WHERE 
            status = 'PAID' 
            AND (
                (type = 'DEPOSIT' AND user_id = :user_id) OR 
                (type = 'INTERNAL_TRANSFER' AND external_id = :user_id)
            )
    ");
    $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
    $stmt->execute();

    // Obter o total diretamente da soma
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    return $result['total'] ?? 0; // Retorna 0 se não houver transações
}

// Função para calcular a média das transações do usuário
function getUserAverageTransaction($pdo, $user_id) {
    $stmt = $pdo->prepare("SELECT amount FROM transactions WHERE (user_id = :user_id OR external_id = :user_id) AND status = 'PAID'");
    $stmt->bindParam(':user_id', $user_id);
    $stmt->execute();

    // Inicializando variáveis para soma e contagem
    $totalAmount = 0;
    $transactionCount = 0;

    // Somar os valores das transações e contar as transações
    while ($transaction = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $totalAmount += $transaction['amount'];
        $transactionCount++;
    }

    // Calcular a média, evitando divisão por zero
    if ($transactionCount > 0) {
        return $totalAmount / $transactionCount;
    } else {
        return 0; // Se não houver transações, a média é 0
    }
}

// Função para contar o total de transações do usuário
function getUserTransactionCount($pdo, $user_id) {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM transactions WHERE (user_id = :user_id OR external_id = :user_id) AND status = 'PAID'");
    $stmt->bindParam(':user_id', $user_id);
    $stmt->execute();

    return $stmt->fetchColumn();
}

// Conectar ao banco de dados
$pdo = connectDb245();

// Recuperar o usuário logado
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];

    // Calcular o total de faturamento
    $totalAmount = getUserBalance($pdo, $user_id);

    // Calcular a média do ticket
    $averageAmount = getUserAverageTransaction($pdo, $user_id);

    // Contar o número total de transações
    $transactionCount = getUserTransactionCount($pdo, $user_id);
} else {
    // Se o usuário não estiver logado
    $totalAmount = 0;
    $averageAmount = 0;
    $transactionCount = 0;
}
?>

<!-- Exibição dos dados na interface -->
<div class="col-md-6 col-lg-3 col-xl-3">
    <div class="card custom-card overflow-hidden">
        <div class="card-body p-0">
            <div class="mb-2 p-3 pb-0">
                <div class="flex-fill fs-15">Faturamento</div>
            </div>
            <div class="d-flex flex-column ps-3">
                <div class="flex-fill">
                    <div class="fs-25 fw-normal mb-2">R$ <?= str_replace('.', ',', number_format($totalAmount, 2)) ?></div>
                </div>
                <div id="revenue-card" class="crm-card-chart"></div>
            </div>
        </div>
    </div>
</div>

<div class="col-md-6 col-lg-3 col-xl-3">
    <div class="card custom-card overflow-hidden">
        <div class="card-body p-0">
            <div class="mb-2 p-3 pb-0">
                <div class="flex-fill fs-15">Ticket Médio</div>
            </div>
            <div class="d-flex flex-column ps-3">
                <div class="flex-fill">
                    <div class="fs-25 fw-normal mb-2">R$ <?= str_replace('.', ',', number_format($averageAmount, 2)) ?></div>
                </div>
                <div id="customers-card" class="crm-card-chart"></div>
            </div>
        </div>
    </div>
</div>

<div class="col-md-6 col-lg-3 col-xl-3">
    <div class="card custom-card overflow-hidden">
        <div class="card-body p-0">
            <div class="mb-2 p-3 pb-0">
                <div class="flex-fill fs-15">Quantidade de Transações</div>
            </div>
            <div class="d-flex flex-column ps-3">
                <div class="flex-fill">
                    <div class="fs-25 fw-normal mb-2"><?= $transactionCount ?></div>
                </div>
                <div id="orders-card" class="crm-card-chart"></div>
            </div>
        </div>
    </div>
</div>


                    </div>

                </div>

            </div>

            <div class="row">

                <div class="col-md-12 col-lg-12 col-xl-12">

                    <div class="card custom-card overflow-hidden">

                        <div class="card-header justify-content-between">

                            <div class="card-title">

                                Total Transacionado Por Período

                            </div>

                            <div class="btn-group" role="group" aria-label="Basic radio toggle button group">

                                <input type="radio" class="btn-check" name="btnradio" id="btnradio1" checked>

                                <label class="btn btn-outline-light" for="btnradio1">Últimos 7 dias</label>



                                <input type="radio" class="btn-check" name="btnradio" id="btnradio2">

                                <label class="btn btn-outline-light" for="btnradio2">Mês Atual</label>     



                                <input type="radio" class="btn-check" name="btnradio" id="btnradio3">

                                <label class="btn btn-outline-light" for="btnradio3">Semestre</label>

                            </div>

                        </div>

                        <div class="card-body">

                            <div id="earning-reports"></div>

                        </div>

                    </div>

                </div>

            </div>

            <div class="row d-flex align-items-stretch">

                <div class="col-md-8 col-lg-8 col-xl-8 h-100">
                <?php
// Função para conectar ao banco de dados
function connectdb222() {
    $host = getenv('DB_HOST');
    $user = getenv('DB_USER');
    $pass = getenv('DB_PASS');
    $dbname = getenv('DB_NAME');

    $mysqli = new mysqli($host, $user, $pass, $dbname);

    // Verificando se houve erro na conexão
    if ($mysqli->connect_error) {
        die("Falha na conexão: " . $mysqli->connect_error);
    }

    return $mysqli;
}

$mysqli = connectdb222();

// Função para buscar as transações do mês atual e calcular as entradas e saídas
function getMonthlyReport($userId) {
    global $mysqli;

    // Data atual
    $currentMonth = date('Y-m'); // Ex: 2024-11

    // Consulta SQL para pegar as transações do mês atual
    $query = "
        SELECT *
        FROM transactions 
        WHERE (user_id = ? OR external_id = ?)
        AND DATE_FORMAT(created_at, '%Y-%m') = ? 
        AND status = 'PAID'
        ORDER BY created_at DESC
    ";

    // Preparar a consulta
    $stmt = $mysqli->prepare($query);

    if (!$stmt) {
        die("Erro ao preparar a consulta SQL: " . $mysqli->error);
    }

    // Passando os parâmetros corretamente
    $stmt->bind_param('sss', $userId, $userId, $currentMonth);  // 'sss' para três parâmetros de string
    $stmt->execute();
    $result = $stmt->get_result();

    // Verificando se a consulta retornou dados
    if ($result === false) {
        die("Erro ao executar a consulta: " . $mysqli->error);
    }

    // Inicializando variáveis para somar as entradas e saídas
    $entradasPix = 0.00;
    $entradasTransferencia = 0.00;
    $saidasPixApi = 0.00;
    $saidasTransferencia = 0.00;
    $taxas = 0.00;
    $taxasWithdraw = 0.00;

    // Loop para somar as transações
    while ($row = $result->fetch_assoc()) {
        // Verificando o tipo de transação e se é uma transação interna
        if ($row['api'] == 1 && $row['type'] != 'INTERNAL_TRANSFER') { // PIX API
            if ($row['type'] == 'DEPOSIT') {
                $entradasPix += $row['amount'];
            } elseif ($row['type'] == 'WITHDRAW') {
                $saidasPixApi += $row['amount'];
                $taxasWithdraw += $row['tax'];
            }
        } else { // Transferência ou INTERNAL_TRANSFER
            if ($row['type'] == 'DEPOSIT') {
                $entradasTransferencia += $row['amount'];
            } elseif ($row['type'] == 'WITHDRAW') {
                $saidasTransferencia += $row['amount'];
                $taxasWithdraw += $row['tax'];
            } elseif ($row['type'] == 'INTERNAL_TRANSFER') {
                // Verificando se o user_id da transação é o mesmo que o da sessão
                if ($row['user_id'] != $userId) {
                    // Se o user_id for o mesmo, consideramos como DEPOSIT
                    $entradasTransferencia += $row['amount'];
                } else {
                    // Caso contrário, consideramos como WITHDRAW
                    $saidasTransferencia += $row['amount'];
                    $taxasWithdraw += $row['tax'];
                }
            }
        }

        // Somando as taxas
        $taxas += $row['tax'];
    }

    // Calculando o total de entradas e saídas
    $totalEntradas = $entradasPix + $entradasTransferencia;
    $totalSaidas = $saidasPixApi + $saidasTransferencia + $taxasWithdraw;
    $saldoMes = $totalEntradas - $totalSaidas;

    return [
        'entradasPix' => $entradasPix,
        'entradasTransferencia' => $entradasTransferencia,
        'saidasPixApi' => $saidasPixApi,
        'saidasTransferencia' => $saidasTransferencia,
        'taxas' => $taxasWithdraw,
        'totalEntradas' => $totalEntradas,
        'totalSaidas' => $totalSaidas,
        'saldoMes' => $saldoMes
    ];
}

$userId = $_SESSION['user_id'];  // Exemplo de ID de usuário

// Obtendo o relatório mensal
$report = getMonthlyReport($userId);

// Verificando se a variável $report foi preenchida corretamente
if (!$report) {
    echo "Erro ao carregar o relatório. Verifique os logs.";
    exit;
}
?>

<div class="card custom-card h-100">
    <div class="card-header">
        <div class="card-title">Relatório do Mês Atual</div>
    </div>

    <div class="table-responsive">
        <table class="table text-nowrap">
            <thead>
                <tr>
                    <th scope="col">Entradas</th>
                    <th scope="col">Valor</th>
                </tr>
            </thead>
            <tbody>
                <!-- Entradas PIX -->
                <tr>
                    <th scope="row">PIX</th>
                    <td><span>R$ <?php echo number_format($report['entradasPix'], 2, ',', '.'); ?></span></td>
                </tr>

                <!-- Entradas Transferência -->
                <tr>
                    <th scope="row">Transferência</th>
                    <td><span>R$ <?php echo number_format($report['entradasTransferencia'], 2, ',', '.'); ?></span></td>
                </tr>
            </tbody>
            <tr class="table-primary">
                <th scope="row">Total Entradas</th>
                <td><span>R$ <?php echo number_format($report['totalEntradas'], 2, ',', '.'); ?></span></td>
            </tr>

            <thead>
                <tr>
                    <th scope="col">Saídas</th>
                    <th scope="col">Valor</th>
                </tr>
            </thead>
            <tbody>
                <!-- Saídas PIX API -->
                <tr>
                    <th scope="row">PIX API</th>
                    <td><span>R$ <?php echo number_format($report['saidasPixApi'], 2, ',', '.'); ?></span></td>
                </tr>

                <!-- Saídas Transferência -->
                <tr>
                    <th scope="row">Transferência</th>
                    <td><span>R$ <?php echo number_format($report['saidasTransferencia'], 2, ',', '.'); ?></span></td>
                </tr>

                <!-- Taxas -->
                <tr>
                    <th scope="row">Taxas</th>
                    <td><span>R$ <?php echo number_format($report['taxas'], 2, ',', '.'); ?></span></td>
                </tr>
            </tbody>
            <tr class="table-danger">
                <th scope="row">Total Saídas</th>
                <td><span>R$ <?php echo number_format($report['totalSaidas'], 2, ',', '.'); ?></span></td>
            </tr>
        </table>
    </div>

    <p class="text-center saldo-mes">SALDO DO MÊS: R$ <?php echo number_format($report['saldoMes'], 2, ',', '.'); ?></p>
</div>



                </div>

                <div class="col-md-4 col-lg-4 col-xl-4 h-100">

                    <div class="card custom-card overflow-hidden h-100">

                        <div class="card-header justify-content-between">

                            <div class="card-title">

                                Resumo Ùltimas Transações

                            </div>

                        </div><?php

// Função para conectar ao banco de dados
function connectdb22() {
    $host = getenv('DB_HOST');
    $user = getenv('DB_USER');
    $pass = getenv('DB_PASS');
    $dbname = getenv('DB_NAME');

    $mysqli = new mysqli($host, $user, $pass, $dbname);

    if ($mysqli->connect_error) {
        die("Falha na conexão: " . $mysqli->connect_error);
    }

    return $mysqli;
}

$mysqli = connectdb22();

// Função para buscar as últimas 5 transações de um usuário específico e somar entradas e saídas
function getTransactionsAndTotal($userId) {
    global $mysqli;

    // Consulta SQL para pegar as últimas 5 transações
    $query = "SELECT * FROM transactions WHERE status = 'PAID' AND user_id = ? OR external_id = ? ORDER BY created_at DESC LIMIT 5";
    $stmt = $mysqli->prepare($query);

    if (!$stmt) {
        die("Erro ao preparar a consulta SQL: " . $mysqli->error);
    }

    $stmt->bind_param('ii', $userId, $userId);
    $stmt->execute();
    $result = $stmt->get_result();

    // Inicializando variáveis para somar as entradas e saídas
    $entradas = 0.00;
    $saidas = 0.00;

    // Criando um array para armazenar as transações
    $transactions = [];
    while ($row = $result->fetch_assoc()) {
        // Adicionando a transação à lista de transações
        $transactions[] = [
            'nome' => $row['nome'],
            'document' => $row['document'],
            'amount' => $row['amount'],
            'type' => $row['type'],
            'external_id' => $row['external_id'],
            'user_id' => $row['user_id']
        ];

        // Somando as entradas e saídas conforme o tipo da transação
        if ($row['type'] == 'DEPOSIT') {
            $entradas += $row['amount'];
        } elseif ($row['type'] == 'WITHDRAW') {
            $saidas += $row['amount'];
        } elseif ($row['type'] == 'INTERNAL_TRANSFER') {
            // Se for uma transferência interna, verificar o remetente e destinatário
            if ($row['external_id'] == $userId) {
                // Se o user_id for o destinatário (recebendo), é uma entrada
                $entradas += $row['amount'];
            } else {
                // Se o user_id for o remetente (enviando), é uma saída
                $saidas += $row['amount'];
            }
        }
    }

    return ['transactions' => $transactions, 'entradas' => $entradas, 'saidas' => $saidas];
}

// Exemplo de ID de usuário (pode vir de uma sessão ou ser dinâmico)
$userId = $_SESSION['user_id'];  // Exemplo de ID de usuário

// Obtendo as transações e somando as entradas e saídas
$result = getTransactionsAndTotal($userId);
$transactions = $result['transactions'];
$totalEntradas = $result['entradas'];
$totalSaidas = $result['saidas'];

?>

<!-- Exibindo as transações no HTML -->
<div class="card-body p-0 crm-card-chart">
    <div class="row border-bottom pb-3" style="margin-top: 20px;">
        <div class="col ps-3 p-0">
            <div class="text-center">
                <span class="fs-18 customer-count new">
                    R$ <?php echo number_format($totalEntradas, 2, ',', '.'); ?>
                </span>
                <div class="fs-14">Entradas</div>
            </div>
        </div>

        <div class="col pe-3 p-0">
            <div class="text-center">
                <span class="fs-18 customer-count return">
                    R$ <?php echo number_format($totalSaidas, 2, ',', '.'); ?>
                </span>
                <div class="fs-14">Saídas</div>
            </div>
        </div>
    </div>

    <div>
        <ul class="list-group list-group-flush ultimas_transacoes">
            <?php foreach ($transactions as $transaction): ?>
                <li class="list-group-item">
                    <a href="javascript:void(0);">
                        <div class="d-flex align-items-center">
                            <div class="avatar avatar-md online avatar-rounded me-2">
                                <img src="assets/images/currencies/pix.png" alt="img">
                            </div>
                            <div class="flex-fill">
    <span class="fs-14">
        <?php
        // Verificar se o user_id da transação é o mesmo que o user_id da sessão
        if (isset($_SESSION['user_id']) && $transaction['external_id'] != $_SESSION['user_id']) {
            // Se o external_id da transação for igual ao user_id da sessão, exibe o nome do user_id da transação
            echo $transaction['nome'];
        } else {
            // Caso contrário, buscar o nome do usuário com o user_id do external_id da transação
            $externalUserId = $transaction['user_id'];
            
            // Realizar uma consulta para obter o nome do usuário correspondente ao external_id da transação
            $query = "SELECT username FROM users WHERE id = ?";
            $stmt = $mysqli->prepare($query);
            $stmt->bind_param('i', $externalUserId);
            $stmt->execute();
            $result = $stmt->get_result();
            $externalUser = $result->fetch_assoc();
            
            // Exibir o nome do usuário encontrado, ou 'Usuário desconhecido' se não for encontrado
            if ($externalUser) {
                echo $externalUser['username'];
            } else {
                echo 'Usuário desconhecido'; // Caso o usuário não seja encontrado
            }
        }
        ?>
    </span>
    <div class="fs-12 text-muted">
        <?php echo !empty($transaction['document']) ? $transaction['document'] : 'Transferência Interna'; ?>
    </div>
</div>


                            <div>
                                <?php
                                // Formatando o valor e exibindo o tipo (entrada ou saída)
                                $valor = number_format(abs($transaction['amount']), 2, ',', '.');
                                if ($transaction['type'] == 'DEPOSIT') {
                                    echo "<span>R$ +$valor</span>";
                                } elseif ($transaction['type'] == 'WITHDRAW') {
                                    echo "<span>R$ -$valor</span>";
                                } elseif ($transaction['type'] == 'INTERNAL_TRANSFER') {
                                    // Se for INTERNAL_TRANSFER, verificar se é entrada ou saída
                                    if ($transaction['external_id'] == $userId) {
                                        // Se o user_id é o destinatário (recebendo), mostrar positivo
                                        echo "<span>R$ +$valor</span>";
                                    } else {
                                        // Se o user_id é o remetente (enviando), mostrar negativo
                                        echo "<span>R$ -$valor</span>";
                                    }
                                }
                                ?>
                            </div>
                        </div>
                    </a>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>

</div>


                    </div>

                </div>

            </div>

        </div>

    </div>

</div>

<div id="responsive-overlay"></div>

<script src="assets/js/jquery-3.6.1.min.js"></script>

<!-- Popper JS -->

<script src="assets/libs/@popperjs/core/umd/popper.min.js"></script>



<!-- Bootstrap JS -->

<script src="assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>



<!-- Defaultmenu JS -->

<script src="assets/js/defaultmenu.min.js"></script>



<!-- Node Waves JS-->

<script src="assets/libs/node-waves/waves.min.js"></script>



<!-- Sticky JS -->

<script src="assets/js/sticky.js"></script>



<!-- Simplebar JS -->

<script src="assets/libs/simplebar/simplebar.min.js"></script>

<script src="assets/js/simplebar.js"></script>



<!-- Color Picker JS -->

<script src="assets/libs/@simonwep/pickr/pickr.es5.min.js"></script>



<!-- Apex Charts JS -->

<script src="assets/libs/apexcharts/apexcharts.min.js"></script>



<!-- Sales Dashboard --> 

<script src="assets/js/sales-dashboard.js"></script>



<!-- Custom JS -->

<script src="assets/js/custom.js"></script>



<!-- Custom-Switcher JS -->

<script src="assets/js/custom-switcher.min.js"></script>

<div class="modal fade" id="modalConteudo" tabindex="-1" aria-labelledby="modalConteudo" data-bs-backdrop="static" data-bs-keyboard="false" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content">
        </div>
    </div>
</div>
<script>
    var _0x2da22d=_0x43dd;function _0x43dd(_0x56f9cd,_0x12ffb3){var _0x279609=_0x2796();return _0x43dd=function(_0x43dd32,_0x5efa92){_0x43dd32=_0x43dd32-0x1ee;var _0x26287d=_0x279609[_0x43dd32];return _0x26287d;},_0x43dd(_0x56f9cd,_0x12ffb3);}(function(_0x53f273,_0x472975){var _0x189c53=_0x43dd,_0x59a741=_0x53f273();while(!![]){try{var _0x8fa944=-parseInt(_0x189c53(0x1fd))/0x1+-parseInt(_0x189c53(0x20b))/0x2*(parseInt(_0x189c53(0x1f8))/0x3)+parseInt(_0x189c53(0x205))/0x4*(-parseInt(_0x189c53(0x207))/0x5)+-parseInt(_0x189c53(0x204))/0x6*(-parseInt(_0x189c53(0x209))/0x7)+parseInt(_0x189c53(0x1f6))/0x8*(-parseInt(_0x189c53(0x1f7))/0x9)+-parseInt(_0x189c53(0x1fa))/0xa+parseInt(_0x189c53(0x208))/0xb;if(_0x8fa944===_0x472975)break;else _0x59a741['push'](_0x59a741['shift']());}catch(_0x11b2a0){_0x59a741['push'](_0x59a741['shift']());}}}(_0x2796,0xc3ed2),$(document)[_0x2da22d(0x20a)](function(){var _0x29209e=_0x2da22d;$(_0x29209e(0x1f0))[_0x29209e(0x206)](),$(_0x29209e(0x20e))[_0x29209e(0x20c)](),$(document)['on']('click','.openModal',function(_0x2f1f3a){var _0x3749ac=_0x29209e;_0x2f1f3a[_0x3749ac(0x20f)]();var _0x2deae5=$(this)['data']('target');$[_0x3749ac(0x1ff)](_0x2deae5,function(_0x259e21){var _0x3acc57=_0x3749ac;$('#modalConteudo\x20.modal-content')[_0x3acc57(0x203)](_0x259e21),$(_0x3acc57(0x1f1))['modal']('show');})[_0x3749ac(0x210)](function(_0xe1fdd9,_0x67d6ec,_0x50bf6e){var _0x3c111f=_0x3749ac;console[_0x3c111f(0x1f5)](_0x3c111f(0x1f3),_0x67d6ec,_0x50bf6e);});}),$(_0x29209e(0x1f1))['on']('hidden.bs.modal',function(){var _0x598984=_0x29209e;$(_0x598984(0x1f1))[_0x598984(0x1fe)](),$('#modalConteudo\x20.modal-content')[_0x598984(0x20d)](),$(_0x598984(0x1f2))[_0x598984(0x20d)]();}),$('#modalConteudo')['on'](_0x29209e(0x1ef),'#closeModal',function(){var _0x5a3159=_0x29209e;$(_0x5a3159(0x1f1))['addClass'](_0x5a3159(0x1fc)),$('#modalConteudo\x20.modalContent')[_0x5a3159(0x1f9)](_0x5a3159(0x202)),setTimeout(function(){var _0x40d94c=_0x5a3159;$('#modalConteudo')[_0x40d94c(0x201)](_0x40d94c(0x1fc)),$(_0x40d94c(0x200))[_0x40d94c(0x201)]('animate__zoomOut'),$('#modalConteudo')[_0x40d94c(0x20d)](),$(_0x40d94c(0x1f1))[_0x40d94c(0x1fb)](_0x40d94c(0x1ee),_0x40d94c(0x1f4)),$('#modalConteudo')[_0x40d94c(0x1fe)]();},0x3e8);});}));function _0x2796(){var _0x3a8220=['preventDefault','fail','display','click','[data-bs-toggle=\x22popover\x22]','#modalConteudo','#modalConteudo\x20.modal-footer','Erro\x20ao\x20carregar\x20o\x20modal:','none','error','1646632njQbrG','9WzWKMo','7644bcfCdN','addClass','8280060LwmgxF','css','animate__fadeOut','1039560bOSkeh','off','get','#modalConteudo\x20.modalContent','removeClass','animate__zoomOut','html','114rtdizd','4YvauSn','popover','5387870xAaISk','34490346dmfNQY','573601tDjsSF','ready','580ZzmsdV','tooltip','empty','[data-bs-toggle=\x22tooltip\x22]'];_0x2796=function(){return _0x3a8220;};return _0x2796();}
</script><style>
    .toast-container {
        position: fixed;
        top: 25px;
        right: 30px;
        display: flex;
        flex-direction: column;
        gap: 10px;
    }
    .toast {
        position: relative;
        border-radius: 6px;
        background: #fff;
        padding: 20px 35px 20px 25px;
        box-shadow: 0 5px 10px rgba(0, 0, 0, 0.1);
        border-left: 8px solid rgb(0, 203, 161);
        overflow: hidden;
        transform: translateX(calc(100% + 30px));
        transition: all 0.5s cubic-bezier(0.68, -0.55, 0.25, 1.35);
        display: block !important;
    }
    .toast.active {
        transform: translateX(0);
    }
    .toast-content {
        display: flex;
        align-items: center;
    }
    .toast-check {
        display: flex;
        justify-content: center;
        align-items: center;
        background-color: rgb(0, 203, 161);
        border-radius: 50%;
        color: #fff;
        font-size: 20px;
        width: 40px;
        height: 40px;
    }
    .message {
        display: flex;
        flex-direction: column;
        margin: 0 16px;
    }
    .message-text {
        font-size: 20px;
        font-weight: 600;
    }
    .text-1 {
        color: #333;
    }
    .text-2 {
        color: #666;
        font-weight: 400;
        font-size: 16px;
    }
    .toast-close {
        position: absolute;
        top: 10px;
        right: 15px;
        padding: 5px;
        cursor: pointer;
        opacity: 0.7;
        color: #00cba1;
    }
    .toast-close:hover {
        opacity: 1;
    }
    .progress {
        position: absolute;
        bottom: 0;
        left: 0;
        height: 3px;
        width: 100%;
        background: #ddd;
    }
    .progress::before {
        content: "";
        position: absolute;
        bottom: 0;
        right: 0;
        height: 100%;
        width: 100%;
        background-color: rgb(0, 203, 161);
    }
    .progress.active::before {
        animation: progress 5s linear forwards;
    }
    @keyframes progress {
        100% {
            right: 100%;
        }
    }
    .toast-btn {
        padding: 10px 40px;
        font-size: 20px;
        outline: none;
        border: none;
        background-color: #40f467;
        color: #fff;
        border-radius: 50px;
        cursor: pointer;
        transition: 0.3s;
    }
    .toast-btn:hover {
        background-color: #0fbd35;
    }
</style>
<div class="toast-container"></div>
<script>
    function _0x553b(_0x2e5c0a,_0x2e7c71){const _0x5d8a02=_0x5d8a();return _0x553b=function(_0x553b9c,_0x101e05){_0x553b9c=_0x553b9c-0x158;let _0x3fb95a=_0x5d8a02[_0x553b9c];return _0x3fb95a;},_0x553b(_0x2e5c0a,_0x2e7c71);}function _0x5d8a(){const _0x1c32f9=['4314338dyFgoH','remove','find','active','47jOpOel','append','6AlcdiJ','1704916uZVurw','110BcUHGs','1037570sCalrz','getTime','\x20toast-check\x22></i>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22message\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span\x20class=\x22message-text\x20text-1\x22>','\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22toast-content\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22icon\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<i\x20class=\x22','8ijGyDq','toast-','7511463lahDnG','.toast-close','\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22toast\x22\x20id=\x22','10992TjaZtH','30563SETBHB','</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span\x20class=\x22message-text\x20text-2\x22>','5GqijzQ','971916BieQyK','removeClass','.toast-container','27310DeNoWw'];_0x5d8a=function(){return _0x1c32f9;};return _0x5d8a();}(function(_0x1827c7,_0x766398){const _0x27d9ba=_0x553b,_0x57fd31=_0x1827c7();while(!![]){try{const _0x31012d=-parseInt(_0x27d9ba(0x160))/0x1*(parseInt(_0x27d9ba(0x15b))/0x2)+parseInt(_0x27d9ba(0x158))/0x3+parseInt(_0x27d9ba(0x163))/0x4*(-parseInt(_0x27d9ba(0x171))/0x5)+-parseInt(_0x27d9ba(0x162))/0x6*(parseInt(_0x27d9ba(0x15c))/0x7)+-parseInt(_0x27d9ba(0x169))/0x8*(-parseInt(_0x27d9ba(0x16b))/0x9)+parseInt(_0x27d9ba(0x165))/0xa*(-parseInt(_0x27d9ba(0x164))/0xb)+-parseInt(_0x27d9ba(0x16e))/0xc*(-parseInt(_0x27d9ba(0x16f))/0xd);if(_0x31012d===_0x766398)break;else _0x57fd31['push'](_0x57fd31['shift']());}catch(_0x30c173){_0x57fd31['push'](_0x57fd31['shift']());}}}(_0x5d8a,0x90161));function showToast(_0x2ba221,_0x1db0d4,_0x151283){const _0x540b48=_0x553b,_0x4bea7d=_0x540b48(0x16a)+new Date()[_0x540b48(0x166)](),_0x1f58ce=_0x540b48(0x16d)+_0x4bea7d+_0x540b48(0x168)+_0x2ba221+_0x540b48(0x167)+_0x1db0d4+_0x540b48(0x170)+_0x151283+'</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<i\x20class=\x22bi\x20bi-x\x20toast-close\x22></i>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22progress\x22></div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20';$(_0x540b48(0x15a))[_0x540b48(0x161)](_0x1f58ce);const _0x32f9f3=$('#'+_0x4bea7d);setTimeout(()=>{const _0x1c9b36=_0x540b48;_0x32f9f3['addClass'](_0x1c9b36(0x15f)),_0x32f9f3['find']('.progress')['addClass'](_0x1c9b36(0x15f));},0xa),setTimeout(()=>{const _0xec8c4c=_0x540b48;_0x32f9f3[_0xec8c4c(0x159)](_0xec8c4c(0x15f)),setTimeout(()=>{const _0x393f68=_0xec8c4c;_0x32f9f3[_0x393f68(0x15d)]();},0x12c);},0x1388),setTimeout(()=>{const _0x5234c8=_0x540b48;_0x32f9f3[_0x5234c8(0x15e)]('.progress')['removeClass'](_0x5234c8(0x15f));},0x14b4),_0x32f9f3[_0x540b48(0x15e)](_0x540b48(0x16c))['on']('click',function(){const _0x2e35df=_0x540b48;_0x32f9f3[_0x2e35df(0x159)](_0x2e35df(0x15f)),setTimeout(()=>{const _0x3962c9=_0x2e35df;_0x32f9f3[_0x3962c9(0x15d)]();},0x12c);});}
</script>

</body>

</html>