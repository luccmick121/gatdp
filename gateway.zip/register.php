<?php
session_start();

if (isset($_SESSION['user_id'])) {
    header("Location: /");
    exit();
}
?>
<html lang="pt-br" dir=" ltr" data-nav-layout="vertical" data-vertical-style="overlay" data-theme-mode="dark" data-header-styles="dark" data-menu-styles="dark" data-toggled="close"><head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <title> <?php include 'libs/get_site_name.php'; ?> - Criar conta </title>

    <meta name="Description" content="Dashboard principal do gateway de pagamento <?php include 'libs/get_site_name.php'; ?>">

    <meta name="Author" content="Ellodev">

	<meta name="keywords" content="Gateway de pagamento">

    <link rel="icon" href="<?php include 'libs/get_site_favicon.php'; ?>" type="image/x-icon">

    <script src="assets/js/authentication-main.js"></script>

    <link id="style" href="assets/libs/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <?php include 'libs/config_css.php'; ?>

    <link href="assets/css/icons.css" rel="stylesheet">

    <?php
    try {
        // Definir variáveis de conexão
        $dbHost = $_ENV['DB_HOST'];
        $dbnome = $_ENV['DB_NAME'];
        $dbUser = $_ENV['DB_USER'];
        $dbPass = $_ENV['DB_PASS'];

        // Conectar ao banco de dados
        $dsn = "mysql:host=$dbHost;dbname=$dbnome;charset=utf8";
        $pdo = new PDO($dsn, $dbUser, $dbPass);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Consultar as cores RGB armazenadas no banco de dados
        $query = "SELECT primary_color, secondary_color FROM config LIMIT 1"; // Supondo que as cores estejam na tabela config
        $stmt = $pdo->prepare($query);
        $stmt->execute();
        $config = $stmt->fetch(PDO::FETCH_ASSOC);

        // Obter as cores RGB do banco, caso não existam, usar valores padrão
        $primaryRgb = isset($config['primary_color']) ? $config['primary_color'] : '0, 203, 161'; // Exemplo de RGB padrão
        $secondaryRgb = isset($config['secondary_color']) ? $config['secondary_color'] : '69, 214, 91'; // Exemplo de RGB padrão
    } catch (PDOException $e) {
        die("Erro ao conectar ao banco de dados: " . $e->getMessage());
    }
    ?>

    <style>
        :root {
            --primary-rgb: <?php echo $primaryRgb; ?>;
            --secondary-rgb: <?php echo $secondaryRgb; ?>;
            --success-rgb: <?php echo $primaryRgb; ?>;
        }
    </style>

</head>

<body class="bg-white">

    <div class="row authentication mx-0">

        <div class="col-xxl-12 col-xl-12 col-lg-12">

            <div class="row justify-content-center align-items-center h-100">

                <div class="col-xxl-8 col-xl-9 col-lg-6 col-md-6 col-sm-8 col-12">

                    <div class="card custom-card shadow-none my-4">

                        <div class="card-body p-4">

                            <div class="mb-3 d-flex justify-content-center">

                                <a href="register">

                                    <img src="<?php include 'libs/get_site_logo.php'; ?>" alt="logo" class="authentication-brand desktop-logo">

                                    <img src="<?php include 'libs/get_site_logo.php'; ?>" alt="logo" class="authentication-brand desktop-dark">

                                </a>

                                <?php include 'libs/check_pay_logo2.php'; ?>

                            </div>

                            <p class="h5 mb-2 text-left">Criar conta</p>

                            <div class="row gy-3">

                                <div class="col-xl-12">

                                    <label for="nome_completo" class="form-label text-default">Nome completo<sup>*</sup></label>

                                    <input type="text" class="form-control form-control-lg" name="nome" id="nome_completo" placeholder="João da Silva">

                                </div>

                                <div class="col-xl-12">

                                    <label for="nome_completo" class="form-label text-default">Nome de usuário<sup>*</sup></label>

                                    <input type="text" class="form-control form-control-lg" name="usuario" id="usuario" placeholder="@joaosilva2">

                                </div>

                                <div class="col-xl-12">

                                    <label for="email" class="form-label email">Email<sup>*</sup></label>

                                    <input type="text" class="form-control form-control-lg" name="email" id="email" placeholder="joaodasilva@gmail.com">

                                </div>

                                <div class="col-xl-12">

                                    <label for="telefone" class="form-label telefone">Telefone<sup>*</sup></label>

                                    <input type="text" class="form-control form-control-lg" name="telefone" id="telefone" placeholder="(11) 90000-0000" inputmode="text">

                                </div>

                                <div class="col-xl-12">

                                    <label for="cnpj" class="form-label cnpj">CPF ou CNPJ<sup>*</sup></label>

                                    <input type="text" class="form-control form-control-lg" name="cnpj" id="cnpj" placeholder="111.111.111-xx">

                                </div>

                                <div class="col-xl-12">

                                    <label for="faturamento" class="form-label text-default">Quanto você fatura por mês?<sup>*</sup></label>

                                    <select class="form-select" name="faturamento" id="faturamento">

                                        <option value="0">Sem faturamento</option>

                                        <option value="1">Abaixo de 100 mil</option>

                                        <option value="2">Entre 100 e 500 mil</option>

                                        <option value="3">Entre 500 e 1 milhão</option>

                                        <option selected="" value="4">Entre 1 e 5 milhões</option>

                                        <option value="5">Mais de 5 milhões</option>

                                    </select>

                                </div>

                                <div class="col-xl-6">

                                    <label for="senha" class="form-label text-default">Senha<sup>*</sup></label>

                                    <div class="position-relative">

                                        <input type="password" class="form-control form-control-lg" name="senha" id="senha" placeholder="Senha">

                                        <a href="javascript:void(0);" class="show-password-button text-muted" onclick="createpassword('senha',this)" id="button-addon2"><i class="ri-eye-off-line align-middle"></i></a>

                                    </div>

                                </div>

                                <div class="col-xl-6">

                                    <label for="confirmar_senha" class="form-label text-default">Confirme a senha<sup>*</sup></label>

                                    <div class="position-relative">

                                        <input type="password" class="form-control form-control-lg" name="confirmar_senha" id="confirmar_senha" placeholder="Confirme a senha">

                                        <a href="javascript:void(0);" class="show-password-button text-muted" onclick="createpassword('confirmar_senha',this)" id="button-addon21"><i class="ri-eye-off-line align-middle"></i></a>

                                    </div>

                                </div>

                                <div class="col-xl-12">

                                    <div class="form-check mt-3">

                                        <input class="form-check-input" type="checkbox" name="termos" value="" id="concordo_termos">

                                        <label class="form-check-label text-muted fw-normal" for="concordo_termos">

                                           Eu li e concordo com os <a class="text-success"><u>Termos e condições</u></a> e a <a class="text-success"><u>Política de Privacidade</u></a>

                                        </label>

                                    </div>

                                </div>

                            </div>

                            <div class="d-grid mt-4">

                                <button class="btn btn-lg btn-primary" id="cadastro-button">Criar conta</button>

                            </div>

                            <div class="text-center">

                                <p class="text-muted mt-3 mb-0">Já tem uma conta? <a href="login" class="text-primary">Fazer login</a></p>

                            </div>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <script src="assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>

    <script src="assets/js/show-password.js"></script>

    <script src="assets/js/inputmask.js"></script>

    <div class="modal fade" id="modalConteudo" tabindex="-1" aria-labelledby="modalConteudo" data-bs-backdrop="static" data-bs-keyboard="false" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content">
        </div>
    </div>
</div>
<script>
    var _0x2da22d=_0x43dd;function _0x43dd(_0x56f9cd,_0x12ffb3){var _0x279609=_0x2796();return _0x43dd=function(_0x43dd32,_0x5efa92){_0x43dd32=_0x43dd32-0x1ee;var _0x26287d=_0x279609[_0x43dd32];return _0x26287d;},_0x43dd(_0x56f9cd,_0x12ffb3);}(function(_0x53f273,_0x472975){var _0x189c53=_0x43dd,_0x59a741=_0x53f273();while(!![]){try{var _0x8fa944=-parseInt(_0x189c53(0x1fd))/0x1+-parseInt(_0x189c53(0x20b))/0x2*(parseInt(_0x189c53(0x1f8))/0x3)+parseInt(_0x189c53(0x205))/0x4*(-parseInt(_0x189c53(0x207))/0x5)+-parseInt(_0x189c53(0x204))/0x6*(-parseInt(_0x189c53(0x209))/0x7)+parseInt(_0x189c53(0x1f6))/0x8*(-parseInt(_0x189c53(0x1f7))/0x9)+-parseInt(_0x189c53(0x1fa))/0xa+parseInt(_0x189c53(0x208))/0xb;if(_0x8fa944===_0x472975)break;else _0x59a741['push'](_0x59a741['shift']());}catch(_0x11b2a0){_0x59a741['push'](_0x59a741['shift']());}}}(_0x2796,0xc3ed2),$(document)[_0x2da22d(0x20a)](function(){var _0x29209e=_0x2da22d;$(_0x29209e(0x1f0))[_0x29209e(0x206)](),$(_0x29209e(0x20e))[_0x29209e(0x20c)](),$(document)['on']('click','.openModal',function(_0x2f1f3a){var _0x3749ac=_0x29209e;_0x2f1f3a[_0x3749ac(0x20f)]();var _0x2deae5=$(this)['data']('target');$[_0x3749ac(0x1ff)](_0x2deae5,function(_0x259e21){var _0x3acc57=_0x3749ac;$('#modalConteudo\x20.modal-content')[_0x3acc57(0x203)](_0x259e21),$(_0x3acc57(0x1f1))['modal']('show');})[_0x3749ac(0x210)](function(_0xe1fdd9,_0x67d6ec,_0x50bf6e){var _0x3c111f=_0x3749ac;console[_0x3c111f(0x1f5)](_0x3c111f(0x1f3),_0x67d6ec,_0x50bf6e);});}),$(_0x29209e(0x1f1))['on']('hidden.bs.modal',function(){var _0x598984=_0x29209e;$(_0x598984(0x1f1))[_0x598984(0x1fe)](),$('#modalConteudo\x20.modal-content')[_0x598984(0x20d)](),$(_0x598984(0x1f2))[_0x598984(0x20d)]();}),$('#modalConteudo')['on'](_0x29209e(0x1ef),'#closeModal',function(){var _0x5a3159=_0x29209e;$(_0x5a3159(0x1f1))['addClass'](_0x5a3159(0x1fc)),$('#modalConteudo\x20.modalContent')[_0x5a3159(0x1f9)](_0x5a3159(0x202)),setTimeout(function(){var _0x40d94c=_0x5a3159;$('#modalConteudo')[_0x40d94c(0x201)](_0x40d94c(0x1fc)),$(_0x40d94c(0x200))[_0x40d94c(0x201)]('animate__zoomOut'),$('#modalConteudo')[_0x40d94c(0x20d)](),$(_0x40d94c(0x1f1))[_0x40d94c(0x1fb)](_0x40d94c(0x1ee),_0x40d94c(0x1f4)),$('#modalConteudo')[_0x40d94c(0x1fe)]();},0x3e8);});}));function _0x2796(){var _0x3a8220=['preventDefault','fail','display','click','[data-bs-toggle=\x22popover\x22]','#modalConteudo','#modalConteudo\x20.modal-footer','Erro\x20ao\x20carregar\x20o\x20modal:','none','error','1646632njQbrG','9WzWKMo','7644bcfCdN','addClass','8280060LwmgxF','css','animate__fadeOut','1039560bOSkeh','off','get','#modalConteudo\x20.modalContent','removeClass','animate__zoomOut','html','114rtdizd','4YvauSn','popover','5387870xAaISk','34490346dmfNQY','573601tDjsSF','ready','580ZzmsdV','tooltip','empty','[data-bs-toggle=\x22tooltip\x22]'];_0x2796=function(){return _0x3a8220;};return _0x2796();}
</script>
    <style>
    .toast-container {
        position: fixed;
        top: 25px;
        right: 30px;
        display: flex;
        flex-direction: column;
        gap: 10px;
    }
    .toast {
        position: relative;
        border-radius: 6px;
        background: #fff;
        padding: 20px 35px 20px 25px;
        box-shadow: 0 5px 10px rgba(0, 0, 0, 0.1);
        border-left: 8px solid rgb(0, 203, 161);
        overflow: hidden;
        transform: translateX(calc(100% + 30px));
        transition: all 0.5s cubic-bezier(0.68, -0.55, 0.25, 1.35);
        display: block !important;
    }
    .toast.active {
        transform: translateX(0);
    }
    .toast-content {
        display: flex;
        align-items: center;
    }
    .toast-check {
        display: flex;
        justify-content: center;
        align-items: center;
        background-color: rgb(0, 203, 161);
        border-radius: 50%;
        color: #fff;
        font-size: 20px;
        width: 40px;
        height: 40px;
    }
    .message {
        display: flex;
        flex-direction: column;
        margin: 0 16px;
    }
    .message-text {
        font-size: 20px;
        font-weight: 600;
    }
    .text-1 {
        color: #333;
    }
    .text-2 {
        color: #666;
        font-weight: 400;
        font-size: 16px;
    }
    .toast-close {
        position: absolute;
        top: 10px;
        right: 15px;
        padding: 5px;
        cursor: pointer;
        opacity: 0.7;
        color: #00cba1;
    }
    .toast-close:hover {
        opacity: 1;
    }
    .progress {
        position: absolute;
        bottom: 0;
        left: 0;
        height: 3px;
        width: 100%;
        background: #ddd;
    }
    .progress::before {
        content: "";
        position: absolute;
        bottom: 0;
        right: 0;
        height: 100%;
        width: 100%;
        background-color: rgb(0, 203, 161);
    }
    .progress.active::before {
        animation: progress 5s linear forwards;
    }
    @keyframes progress {
        100% {
            right: 100%;
        }
    }
    .toast-btn {
        padding: 10px 40px;
        font-size: 20px;
        outline: none;
        border: none;
        background-color: #40f467;
        color: #fff;
        border-radius: 50px;
        cursor: pointer;
        transition: 0.3s;
    }
    .toast-btn:hover {
        background-color: #0fbd35;
    }
</style>
<div class="toast-container"></div>
<script>
    function _0x553b(_0x2e5c0a,_0x2e7c71){const _0x5d8a02=_0x5d8a();return _0x553b=function(_0x553b9c,_0x101e05){_0x553b9c=_0x553b9c-0x158;let _0x3fb95a=_0x5d8a02[_0x553b9c];return _0x3fb95a;},_0x553b(_0x2e5c0a,_0x2e7c71);}function _0x5d8a(){const _0x1c32f9=['4314338dyFgoH','remove','find','active','47jOpOel','append','6AlcdiJ','1704916uZVurw','110BcUHGs','1037570sCalrz','getTime','\x20toast-check\x22></i>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22message\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span\x20class=\x22message-text\x20text-1\x22>','\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22toast-content\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22icon\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<i\x20class=\x22','8ijGyDq','toast-','7511463lahDnG','.toast-close','\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22toast\x22\x20id=\x22','10992TjaZtH','30563SETBHB','</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span\x20class=\x22message-text\x20text-2\x22>','5GqijzQ','971916BieQyK','removeClass','.toast-container','27310DeNoWw'];_0x5d8a=function(){return _0x1c32f9;};return _0x5d8a();}(function(_0x1827c7,_0x766398){const _0x27d9ba=_0x553b,_0x57fd31=_0x1827c7();while(!![]){try{const _0x31012d=-parseInt(_0x27d9ba(0x160))/0x1*(parseInt(_0x27d9ba(0x15b))/0x2)+parseInt(_0x27d9ba(0x158))/0x3+parseInt(_0x27d9ba(0x163))/0x4*(-parseInt(_0x27d9ba(0x171))/0x5)+-parseInt(_0x27d9ba(0x162))/0x6*(parseInt(_0x27d9ba(0x15c))/0x7)+-parseInt(_0x27d9ba(0x169))/0x8*(-parseInt(_0x27d9ba(0x16b))/0x9)+parseInt(_0x27d9ba(0x165))/0xa*(-parseInt(_0x27d9ba(0x164))/0xb)+-parseInt(_0x27d9ba(0x16e))/0xc*(-parseInt(_0x27d9ba(0x16f))/0xd);if(_0x31012d===_0x766398)break;else _0x57fd31['push'](_0x57fd31['shift']());}catch(_0x30c173){_0x57fd31['push'](_0x57fd31['shift']());}}}(_0x5d8a,0x90161));function showToast(_0x2ba221,_0x1db0d4,_0x151283){const _0x540b48=_0x553b,_0x4bea7d=_0x540b48(0x16a)+new Date()[_0x540b48(0x166)](),_0x1f58ce=_0x540b48(0x16d)+_0x4bea7d+_0x540b48(0x168)+_0x2ba221+_0x540b48(0x167)+_0x1db0d4+_0x540b48(0x170)+_0x151283+'</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<i\x20class=\x22bi\x20bi-x\x20toast-close\x22></i>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22progress\x22></div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20';$(_0x540b48(0x15a))[_0x540b48(0x161)](_0x1f58ce);const _0x32f9f3=$('#'+_0x4bea7d);setTimeout(()=>{const _0x1c9b36=_0x540b48;_0x32f9f3['addClass'](_0x1c9b36(0x15f)),_0x32f9f3['find']('.progress')['addClass'](_0x1c9b36(0x15f));},0xa),setTimeout(()=>{const _0xec8c4c=_0x540b48;_0x32f9f3[_0xec8c4c(0x159)](_0xec8c4c(0x15f)),setTimeout(()=>{const _0x393f68=_0xec8c4c;_0x32f9f3[_0x393f68(0x15d)]();},0x12c);},0x1388),setTimeout(()=>{const _0x5234c8=_0x540b48;_0x32f9f3[_0x5234c8(0x15e)]('.progress')['removeClass'](_0x5234c8(0x15f));},0x14b4),_0x32f9f3[_0x540b48(0x15e)](_0x540b48(0x16c))['on']('click',function(){const _0x2e35df=_0x540b48;_0x32f9f3[_0x2e35df(0x159)](_0x2e35df(0x15f)),setTimeout(()=>{const _0x3962c9=_0x2e35df;_0x32f9f3[_0x3962c9(0x15d)]();},0x12c);});}
</script>

    <script>

        const _0x3df67c=_0x3767;function _0x3767(_0x11eafb,_0x1e57da){const _0xc7e8e7=_0xc7e8();return _0x3767=function(_0x37672b,_0x41fee7){_0x37672b=_0x37672b-0x1e3;let _0x31ff30=_0xc7e8e7[_0x37672b];return _0x31ff30;},_0x3767(_0x11eafb,_0x1e57da);}function _0xc7e8(){const _0x4cd66b=['#nome_completo','ready','termos','cnpj','$1.$2.$3','Sucesso','As\x20senhas\x20não\x20coincidem','bi\x20bi-exclamation-triangle','#usuario','status','2879866LEgTav','telefone','substring','109821pMwUvs','905292KCwrxg','CPF\x20inválido','434TrFVBP','location','error','950732CmbXJE','90096wJDOzy','4639936QKqesv','confirmar_senha','Preencha\x20todos\x20os\x20dados\x20corretamente','length','1411450qWwWbz','#email','href','val','charAt','15vgMlRr','stringify','email','Cadastro\x20realizado','nome','#concordo_termos','POST','input','Redirecionando...','10PfxLlI','#telefone','#senha','inputmask',':checked','$1.$2','20sBTKAq','preventDefault','#confirmar_senha','responseText','success','usuario','bi\x20bi-check-lg','Erro','#cadastro-button','senha','test','#faturamento','replace','application/json','$1-$2'];_0xc7e8=function(){return _0x4cd66b;};return _0xc7e8();}(function(_0x5b4e1c,_0x434564){const _0x2cccc0=_0x3767,_0xb3ba9f=_0x5b4e1c();while(!![]){try{const _0x1b37ca=parseInt(_0x2cccc0(0x20e))/0x1*(parseInt(_0x2cccc0(0x1f2))/0x2)+parseInt(_0x2cccc0(0x1e3))/0x3*(parseInt(_0x2cccc0(0x214))/0x4)+-parseInt(_0x2cccc0(0x21a))/0x5+parseInt(_0x2cccc0(0x215))/0x6*(-parseInt(_0x2cccc0(0x211))/0x7)+-parseInt(_0x2cccc0(0x216))/0x8+parseInt(_0x2cccc0(0x20f))/0x9*(-parseInt(_0x2cccc0(0x1ec))/0xa)+parseInt(_0x2cccc0(0x20b))/0xb;if(_0x1b37ca===_0x434564)break;else _0xb3ba9f['push'](_0xb3ba9f['shift']());}catch(_0x44060d){_0xb3ba9f['push'](_0xb3ba9f['shift']());}}}(_0xc7e8,0x9fce9),$(document)[_0x3df67c(0x202)](function(){const _0x1faa1f=_0x3df67c;$(_0x1faa1f(0x209))['on'](_0x1faa1f(0x1ea),function(){const _0xada970=_0x1faa1f;var _0x9b71b6=$(this)[_0xada970(0x21d)](),_0x47114e=_0x9b71b6['replace'](/[^a-zA-Z0-9]/g,'');$(this)[_0xada970(0x21d)](_0x47114e);}),$(_0x1faa1f(0x1ed))[_0x1faa1f(0x1ef)]('(99)\x2099999-9999');function _0x98aea7(_0x478018){const _0x527687=_0x1faa1f;return _0x478018=_0x478018[_0x527687(0x1fe)](/\D/g,''),_0x478018['length']<=0xb?(_0x478018=_0x478018[_0x527687(0x1fe)](/(\d{3})(\d)/,_0x527687(0x1f1)),_0x478018=_0x478018[_0x527687(0x1fe)](/(\d{3})(\d)/,'$1.$2'),_0x478018=_0x478018['replace'](/(\d{3})(\d{1,2})$/,_0x527687(0x200))):(_0x478018=_0x478018['replace'](/^(\d{2})(\d)/,_0x527687(0x1f1)),_0x478018=_0x478018[_0x527687(0x1fe)](/^(\d{2})\.(\d{3})(\d)/,_0x527687(0x205)),_0x478018=_0x478018[_0x527687(0x1fe)](/\.(\d{3})(\d)/,'.$1/$2'),_0x478018=_0x478018[_0x527687(0x1fe)](/(\d{4})(\d)/,_0x527687(0x200))),_0x478018;}function _0x219843(_0x2d913e){const _0x2cad39=_0x1faa1f;_0x2d913e=_0x2d913e['replace'](/[^\d]+/g,'');if(_0x2d913e[_0x2cad39(0x219)]!==0xb||/^(\d)\1+$/[_0x2cad39(0x1fc)](_0x2d913e))return![];let _0x190d17=0x0,_0x40d4b7;for(let _0x135807=0x1;_0x135807<=0x9;_0x135807++)_0x190d17+=parseInt(_0x2d913e[_0x2cad39(0x20d)](_0x135807-0x1,_0x135807))*(0xb-_0x135807);_0x40d4b7=_0x190d17*0xa%0xb;if(_0x40d4b7===0xa||_0x40d4b7===0xb)_0x40d4b7=0x0;if(_0x40d4b7!==parseInt(_0x2d913e[_0x2cad39(0x20d)](0x9,0xa)))return![];_0x190d17=0x0;for(let _0x5ba497=0x1;_0x5ba497<=0xa;_0x5ba497++)_0x190d17+=parseInt(_0x2d913e['substring'](_0x5ba497-0x1,_0x5ba497))*(0xc-_0x5ba497);_0x40d4b7=_0x190d17*0xa%0xb;if(_0x40d4b7===0xa||_0x40d4b7===0xb)_0x40d4b7=0x0;if(_0x40d4b7!==parseInt(_0x2d913e['substring'](0xa,0xb)))return![];return!![];}function _0x4c7a76(_0x451c2f){const _0x2b37d2=_0x1faa1f;_0x451c2f=_0x451c2f['replace'](/[^\d]+/g,'');if(_0x451c2f['length']!==0xe)return![];let _0x3465ac=_0x451c2f['length']-0x2,_0x266a11=_0x451c2f[_0x2b37d2(0x20d)](0x0,_0x3465ac),_0x1b3e6e=_0x451c2f[_0x2b37d2(0x20d)](_0x3465ac),_0x4c343c=0x0,_0x4e1f5c=_0x3465ac-0x7;for(let _0x15236c=_0x3465ac;_0x15236c>=0x1;_0x15236c--){_0x4c343c+=_0x266a11[_0x2b37d2(0x21e)](_0x3465ac-_0x15236c)*_0x4e1f5c--;if(_0x4e1f5c<0x2)_0x4e1f5c=0x9;}let _0x1d0462=_0x4c343c%0xb<0x2?0x0:0xb-_0x4c343c%0xb;if(_0x1d0462!==parseInt(_0x1b3e6e[_0x2b37d2(0x21e)](0x0)))return![];_0x3465ac=_0x3465ac+0x1,_0x266a11=_0x451c2f[_0x2b37d2(0x20d)](0x0,_0x3465ac),_0x4c343c=0x0,_0x4e1f5c=_0x3465ac-0x7;for(let _0x287daa=_0x3465ac;_0x287daa>=0x1;_0x287daa--){_0x4c343c+=_0x266a11[_0x2b37d2(0x21e)](_0x3465ac-_0x287daa)*_0x4e1f5c--;if(_0x4e1f5c<0x2)_0x4e1f5c=0x9;}_0x1d0462=_0x4c343c%0xb<0x2?0x0:0xb-_0x4c343c%0xb;if(_0x1d0462!==parseInt(_0x1b3e6e[_0x2b37d2(0x21e)](0x1)))return![];return!![];}$('#cnpj')['on'](_0x1faa1f(0x1ea),function(){const _0x4758aa=_0x1faa1f;var _0x5d661e=$(this)[_0x4758aa(0x21d)](),_0x3661fa=_0x5d661e[_0x4758aa(0x1fe)](/\D/g,'');_0x3661fa[_0x4758aa(0x219)]>0xe&&(_0x3661fa=_0x3661fa[_0x4758aa(0x20d)](0x0,0xe));var _0x4a90e6=_0x98aea7(_0x3661fa);$(this)['val'](_0x4a90e6);}),$(_0x1faa1f(0x1fa))['on']('click',function(_0x5341cb){const _0x3aaa75=_0x1faa1f;_0x5341cb[_0x3aaa75(0x1f3)]();var _0x1f90d7={'nome':$(_0x3aaa75(0x201))['val'](),'email':$(_0x3aaa75(0x21b))[_0x3aaa75(0x21d)](),'telefone':$('#telefone')['val'](),'usuario':$(_0x3aaa75(0x209))[_0x3aaa75(0x21d)](),'cnpj':$('#cnpj')[_0x3aaa75(0x21d)](),'faturamento':$(_0x3aaa75(0x1fd))[_0x3aaa75(0x21d)](),'senha':$(_0x3aaa75(0x1ee))['val'](),'confirmar_senha':$(_0x3aaa75(0x1f4))[_0x3aaa75(0x21d)](),'termos':$(_0x3aaa75(0x1e8))['is'](_0x3aaa75(0x1f0))};if(!_0x1f90d7[_0x3aaa75(0x1e7)]||!_0x1f90d7[_0x3aaa75(0x1e5)]||!_0x1f90d7[_0x3aaa75(0x20c)]||!_0x1f90d7[_0x3aaa75(0x1f7)]||!_0x1f90d7[_0x3aaa75(0x204)]||!_0x1f90d7[_0x3aaa75(0x1fb)]||!_0x1f90d7['confirmar_senha']||!_0x1f90d7[_0x3aaa75(0x203)]){showToast(_0x3aaa75(0x208),_0x3aaa75(0x1f9),_0x3aaa75(0x218));return;}if(_0x1f90d7[_0x3aaa75(0x1fb)]!==_0x1f90d7[_0x3aaa75(0x217)]){showToast(_0x3aaa75(0x208),_0x3aaa75(0x1f9),_0x3aaa75(0x207));return;}var _0x1d6329=_0x1f90d7[_0x3aaa75(0x204)][_0x3aaa75(0x219)]<=0xe?_0x219843(_0x1f90d7[_0x3aaa75(0x204)]):_0x4c7a76(_0x1f90d7[_0x3aaa75(0x204)]);if(!_0x1d6329){showToast(_0x3aaa75(0x208),'Erro',_0x1f90d7[_0x3aaa75(0x204)][_0x3aaa75(0x219)]<=0xe?_0x3aaa75(0x210):'CNPJ\x20inválido');return;}$['ajax']({'url':'libs/funcoes/valida_cadastro','type':_0x3aaa75(0x1e9),'contentType':_0x3aaa75(0x1ff),'data':JSON[_0x3aaa75(0x1e4)](_0x1f90d7),'success':function(_0x5af8fe){const _0x12c0d1=_0x3aaa75;var _0x896e52=JSON['parse'](_0x5af8fe);_0x896e52[_0x12c0d1(0x20a)]===_0x12c0d1(0x1f6)?(showToast(_0x12c0d1(0x1f8),_0x12c0d1(0x206),_0x12c0d1(0x1e6)),setTimeout(()=>{const _0x1d3e7f=_0x12c0d1;showToast(_0x1d3e7f(0x1f8),_0x1d3e7f(0x206),_0x1d3e7f(0x1eb));},0x3e8),setTimeout(()=>{const _0x350719=_0x12c0d1;window[_0x350719(0x212)][_0x350719(0x21c)]='./';},0x5dc)):showToast('bi\x20bi-exclamation-triangle',_0x12c0d1(0x1f9),_0x896e52['message']);},'error':function(_0x3098f0,_0x3c7b6b,_0x46cc78){const _0x535159=_0x3aaa75;console[_0x535159(0x213)](_0x3098f0[_0x535159(0x1f5)]),showToast('bi\x20bi-exclamation-triangle','Erro',_0x3098f0[_0x535159(0x1f5)]);}});});}));

    </script>



</body></html>