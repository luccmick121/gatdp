<?php
session_start();

// Verificar se o usuário está autenticado
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login');
    exit;
}

use Dotenv\Dotenv;

require __DIR__ . '/../vendor/autoload.php';

$dotenv = Dotenv::createImmutable(__DIR__ . '/../');
$dotenv->load();

try {
    $dbHost = $_ENV['DB_HOST'];
    $dbnome = $_ENV['DB_NAME'];
    $dbUser = $_ENV['DB_USER'];
    $dbPass = $_ENV['DB_PASS'];

    $dsn = "mysql:host=$dbHost;dbname=$dbnome;charset=utf8";
    $pdo = new PDO($dsn, $dbUser, $dbPass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Erro ao conectar ao banco de dados: " . $e->getMessage());
}

// Processar as requisições POST (aprovar ou recusar documentos)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');

    $document_id = isset($_POST['document_id']) ? (int)$_POST['document_id'] : 0;
    $action = isset($_POST['action']) ? trim($_POST['action']) : '';

    if ($document_id > 0 && in_array($action, ['approve', 'reject'])) {
        try {
            if ($action === 'approve') {
                try {
                    // Aprovar o documento
                    $status = 1; // 1 = aprovado
                    $stmt = $pdo->prepare("UPDATE users_documents SET approved = :status WHERE id = :document_id");
                    $stmt->bindValue(':status', $status, PDO::PARAM_INT);
                    $stmt->bindValue(':document_id', $document_id, PDO::PARAM_INT);
                    $stmt->execute();
            
                    // Buscar o user_id para realizar a verificação
                    $stmt_document = $pdo->prepare("SELECT user_id FROM users_documents WHERE id = :document_id");
                    $stmt_document->bindValue(':document_id', $document_id, PDO::PARAM_INT);
                    $stmt_document->execute();
                    $document = $stmt_document->fetch(PDO::FETCH_ASSOC);
            
                    if ($document) {
                        // Verificar se todos os documentos 1-4 do usuário estão aprovados
$stmt_check = $pdo->prepare("
SELECT COUNT(*) 
FROM users_documents 
WHERE user_id = :user_id AND document_id IN (1, 2, 3, 4) AND approved = 1
");
$stmt_check->bindValue(':user_id', $document['user_id'], PDO::PARAM_INT);
$stmt_check->execute();
$approved_documents = $stmt_check->fetchColumn();

// Se todos os documentos 1-4 estiverem aprovados
if ($approved_documents == 4) {
// Atualizar a coluna documents_checked para 1
$stmt_user = $pdo->prepare("UPDATE users SET documents_checked = 1 WHERE id = :user_id");
$stmt_user->bindValue(':user_id', $document['user_id'], PDO::PARAM_INT);
$stmt_user->execute();

echo json_encode([ 
    'status' => 'success',
    'message' => 'Documento aprovado e todos os documentos verificados para o usuário!',
]);
} else {
echo json_encode([ 
    'status' => 'success',
    'message' => 'Documento aprovado, mas o usuário ainda tem documentos pendentes.',
]);
}
                    }
            
                } catch (PDOException $e) {
                    echo json_encode([ 
                        'status' => 'error',
                        'message' => 'Erro ao processar a ação de aprovação: ' . $e->getMessage(),
                    ]);
                }
            } elseif ($action === 'reject') {
                // Recusar o documento (deletar)
                $stmt = $pdo->prepare("DELETE FROM users_documents WHERE id = :document_id");
                $stmt->bindValue(':document_id', $document_id, PDO::PARAM_INT);
                $stmt->execute();

                echo json_encode([ 
                    'status' => 'success',
                    'message' => 'Documento recusado e deletado com sucesso!',
                ]);
            }
        } catch (PDOException $e) {
            echo json_encode([ 
                'status' => 'error',
                'message' => 'Erro ao processar a ação: ' . $e->getMessage(),
            ]);
        }
    } else {
        echo json_encode([ 
            'status' => 'error',
            'message' => 'Dados inválidos fornecidos.',
        ]);
    }

    exit;
}

// Configuração inicial de variáveis
$search = ""; // Definir $search como vazio por padrão
$documents = []; // Definir $documents como array vazio por padrão

// Verificar se há busca
if (isset($_GET['search']) && !empty($_GET['search'])) {
    $search = trim($_GET['search']);
}

// Consultar documentos com ou sem filtro por usuário
$query = "
    SELECT DISTINCT d.id AS document_unique_id, u.id AS user_id, u.name, u.username, d.document_id, d.file_path, d.approved 
    FROM users_documents d
    JOIN users u ON u.id = d.user_id
    WHERE d.approved = 0
";
if (!empty($search)) {
    $query .= " AND u.username LIKE :search";
}

$stmt = $pdo->prepare($query);

if (!empty($search)) {
    $stmt->bindValue(':search', "%$search%", PDO::PARAM_STR);
}
$stmt->execute();

$documents = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Função para determinar o tipo de documento com base no document_id
function getDocumentType($document_id) {
    switch ($document_id) {
        case 1: return "Frente";
        case 2: return "Verso";
        case 3: return "Segurando Documento";
        case 4: return "Contrato Social";
        default: return "Tipo Desconhecido";
    }
}

// Função para ajustar o caminho do arquivo (cortar tudo antes de /libs ou \libs)
function adjustFilePath($filePath) {
    // Substitui tudo antes da pasta 'libs' e mantém o caminho relativo a partir de 'libs'
    $adjustedPath = preg_replace('/^.*?[\\\\\/]libs/', '', $filePath);
    return '/libs' . $adjustedPath;
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Documentos</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <style>
        .semibold {
            font-weight: 600;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <h1>Lista de Documentos</h1>

        <!-- Formulário de busca -->
        <form method="GET" action="" class="form-inline mb-3">
            <input type="text" name="search" class="form-control mr-2" placeholder="Buscar por username" value="<?php echo htmlspecialchars($search); ?>">
            <button type="submit" class="btn btn-primary">Buscar</button>
            <a href="?" class="btn btn-secondary ml-2">Limpar</a>
        </form>

        <!-- Botão Voltar -->
        <a href="../admin" class="btn btn-info mb-3">Voltar</a>

        <?php if (count($documents) > 0): ?>
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nome Completo</th>
                        <th>Username</th>
                        <th>Tipo de Documento</th>
                        <th>Documento</th>
                        <th>Status</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody id="documents-list">
                    <?php foreach ($documents as $document): ?>
                        <tr id="doc-<?php echo htmlspecialchars($document['document_unique_id']); ?>">
                            <td><?php echo htmlspecialchars($document['document_unique_id']); ?></td>
                            <td><?php echo htmlspecialchars($document['name']); ?></td>
                            <td><?php echo htmlspecialchars($document['username']); ?></td>
                            <td><?php echo getDocumentType($document['document_id']); ?></td>
                            <td>
                                <a href="<?php echo adjustFilePath($document['file_path']); ?>" target="_blank">Abrir Documento</a>
                            </td>
                            <td class="semibold">
                                <span class="text-warning">Pendente</span>
                            </td>
                            <td>
                                <button class="btn btn-success btn-sm approve-btn" data-id="<?php echo htmlspecialchars($document['document_unique_id']); ?>">Aprovar</button>
                                <button class="btn btn-danger btn-sm reject-btn" data-id="<?php echo htmlspecialchars($document['document_unique_id']); ?>">Recusar</button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>Não há documentos pendentes no momento.</p>
        <?php endif; ?>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            // Aprovar Documento
            document.querySelectorAll('.approve-btn').forEach(function (button) {
                button.addEventListener('click', function () {
                    const documentId = this.getAttribute('data-id');
                    handleAction(documentId, 'approve');
                });
            });

            // Recusar Documento
            document.querySelectorAll('.reject-btn').forEach(function (button) {
                button.addEventListener('click', function () {
                    const documentId = this.getAttribute('data-id');
                    handleAction(documentId, 'reject');
                });
            });

            function handleAction(documentId, action) {
                fetch('', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: `document_id=${documentId}&action=${action}`
                })
                .then(response => response.json())
                .then(data => {
                    console.log(data);  // Verifique o que está sendo retornado aqui
                    if (data.status === 'success') {
                        document.getElementById(`doc-${documentId}`).remove();
                        alert(data.message);
                    } else {
                        alert('Erro: ' + data.message);
                    }
                })
                .catch(error => console.error('Erro:', error));
            }
        });
    </script>
</body>
</html>
