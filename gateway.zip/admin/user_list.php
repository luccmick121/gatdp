<?php
session_start();

// Verificar se o usuário está autenticado
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login'); // Redireciona para a página de login se não estiver autenticado
    exit;
}

use Dotenv\Dotenv;

require __DIR__ . '/../vendor/autoload.php';

$dotenv = Dotenv::createImmutable(__DIR__ . '/../');
$dotenv->load();

try {
    $dbHost = $_ENV['DB_HOST'];
    $dbName = $_ENV['DB_NAME'];
    $dbUser = $_ENV['DB_USER'];
    $dbPass = $_ENV['DB_PASS'];

    $dsn = "mysql:host=$dbHost;dbname=$dbName;charset=utf8";
    $pdo = new PDO($dsn, $dbUser, $dbPass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Erro ao conectar ao banco de dados: " . $e->getMessage());
}

// Consultar o role do usuário com base no user_id da sessão
$user_id = $_SESSION['user_id'];
$query = "SELECT id, username, email, role FROM users WHERE id = :user_id";
$stmt = $pdo->prepare($query);
$stmt->execute([':user_id' => $user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// Verificar se o usuário existe no banco
if (!$user) {
    header('Location: ../login'); // Redireciona para o login se o usuário não for encontrado
    exit;
}

// Verificar se o usuário tem a role 'admin'
if ($user['role'] !== 'ADMIN') {
    header('Location: ../login'); // Redireciona para o login se não for admin
    exit;
}

// Configuração de limite e paginação
$limit = 10; // Número de registros por página
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1; // Página atual
$offset = ($page - 1) * $limit; // Calcular o offset

// Lidar com o formulário de busca
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

// Consultar todos os usuários do banco de dados com base na pesquisa e paginação
$query = "SELECT id, username, email, role, balance 
          FROM users 
          WHERE username LIKE :search 
          LIMIT :limit OFFSET :offset";

$stmt = $pdo->prepare($query);
$stmt->bindValue(':search', '%' . $search . '%', PDO::PARAM_STR);
$stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Consultar o número total de registros (para paginação)
$totalQuery = "SELECT COUNT(*) FROM users WHERE username LIKE :search";
$totalStmt = $pdo->prepare($totalQuery);
$totalStmt->bindValue(':search', '%' . $search . '%', PDO::PARAM_STR);
$totalStmt->execute();
$totalUsers = $totalStmt->fetchColumn();
$totalPages = ceil($totalUsers / $limit); // Total de páginas


// Consultas para obter os totais de contas e outros dados
// Total de contas
$queryTotalUsers = "SELECT COUNT(*) FROM users";
$stmtTotalUsers = $pdo->prepare($queryTotalUsers);
$stmtTotalUsers->execute();
$totalUsers = $stmtTotalUsers->fetchColumn();

// Total de contas com cash_in ativo
$queryTotalCashIn = "SELECT COUNT(*) FROM users WHERE cash_in_active = 1";
$stmtTotalCashIn = $pdo->prepare($queryTotalCashIn);
$stmtTotalCashIn->execute();
$totalCashIn = $stmtTotalCashIn->fetchColumn();

// Total de contas com cash_out ativo
$queryTotalCashOut = "SELECT COUNT(*) FROM users WHERE cash_out_active = 1";
$stmtTotalCashOut = $pdo->prepare($queryTotalCashOut);
$stmtTotalCashOut->execute();
$totalCashOut = $stmtTotalCashOut->fetchColumn();

// Total de contas com documentos ativos
$queryTotalDocuments = "SELECT COUNT(*) FROM users_documents WHERE approved = 0";
$stmtTotalDocuments = $pdo->prepare($queryTotalDocuments);
$stmtTotalDocuments->execute();
$totalDocuments = $stmtTotalDocuments->fetchColumn();

// Total de saldo das contas
$queryTotalBalance = "SELECT SUM(balance) FROM users";
$stmtTotalBalance = $pdo->prepare($queryTotalBalance);
$stmtTotalBalance->execute();
$totalBalance = $stmtTotalBalance->fetchColumn();

// Total de transações
$queryTotalTransactions = "SELECT COUNT(*) FROM transactions";
$stmtTotalTransactions = $pdo->prepare($queryTotalTransactions);
$stmtTotalTransactions->execute();
$totalTransactions = $stmtTotalTransactions->fetchColumn();

// Consultar o total movimentado (soma de todos os amounts das transações com status PAID)
$queryTotalMovimentado = "SELECT SUM(amount) FROM transactions WHERE status = 'PAID'";
$stmtTotalMovimentado = $pdo->prepare($queryTotalMovimentado);
$stmtTotalMovimentado->execute();
$totalMovimentado = $stmtTotalMovimentado->fetchColumn();

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Lista de Contas</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h1>Lista de Contas de Usuários</h1>

        <!-- Resumo Total no Topo -->
        <div class="row mb-4 mt-4"> <!-- Adicionando margin-top mt-4 -->
            <div class="col-md-4">
                <h5>Total de Contas: <?php echo $totalUsers; ?></h5>
            </div>
            <div class="col-md-4">
                <h5>Total de Contas com Cash In Ativo: <?php echo $totalCashIn; ?></h5>
            </div>
            <div class="col-md-4">
                <h5>Total de Contas com Cash Out Ativo: <?php echo $totalCashOut; ?></h5>
            </div>
            <div class="col-md-4">
                <h5>Total de Documentos Ativos: <?php echo $totalDocuments; ?></h5>
            </div>
            <div class="col-md-4">
                <h5>Total de Saldo das Contas: R$ <?php echo number_format($totalBalance, 2, ',', '.'); ?></h5>
            </div>
            <div class="col-md-4">
                <h5>Total de Transações: <?php echo $totalTransactions; ?></h5>
            </div>
            <!-- Adicionando a exibição do total movimentado -->
            <div class="col-md-4">
                <h5>Total Movimentado (PAID): R$ 
                    <?php 
                        echo number_format($totalMovimentado ?? 0, 2, ',', '.'); 
                    ?>
                </h5>
            </div>

        </div>

        <!-- Formulário de Busca -->
        <form method="GET" class="mb-4">
            <div class="input-group">
                <input type="text" name="search" class="form-control mr-2" placeholder="Buscar por usuário" value="<?php echo htmlspecialchars($search); ?>">
                <div class="input-group-append">
                    <button class="btn btn-primary" type="submit">Buscar</button>
                </div>
            </div>
        </form>
        
        <!-- Menu de Navegação -->
        <?php
        // Assumindo que a conexão com o banco de dados já foi realizada anteriormente

        // Consultar o número de documentos com approved = 0
        $query = "SELECT COUNT(*) AS pending_documents FROM users_documents WHERE approved = 0";
        $stmt = $pdo->prepare($query);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        // Obter o número de documentos pendentes
        $pending_documents = $result['pending_documents'];
        ?>

        <div class="mb-3">
            <a href="user_list.php" class="btn btn-primary">Usuários</a>
            <a href="transaction_list.php" class="btn btn-secondary">Transações</a>
            <a href="documents_list" class="btn btn-secondary">
                Documentos
                <?php if ($pending_documents > 0): ?>
                    <span class="badge badge-danger ml-2"><?php echo $pending_documents; ?></span>
                <?php endif; ?>
            </a>
            <a href="config_edit.php" class="btn btn-secondary">Configurações do Site</a>
        </div>


        <a href="../" class="btn btn-danger mb-3">Sair</a>


        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Usuário</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Saldo</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($users)): ?>
                    <tr>
                        <td colspan="6" class="text-center">Nenhum usuário encontrado.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($users as $user): ?>
                        <tr>
                            <td><?php echo $user['id']; ?></td>
                            <td><?php echo htmlspecialchars($user['username']); ?></td>
                            <td><?php echo htmlspecialchars($user['email']); ?></td>
                            <td><?php echo htmlspecialchars($user['role']); ?></td>
                            <td><?php echo htmlspecialchars($user['balance']); ?></td>
                            <td>
                                <a href="edit_user.php?id=<?php echo $user['id']; ?>" class="btn btn-warning btn-sm">Editar</a>
                                <a href="delete_user.php?id=<?php echo $user['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Tem certeza que deseja excluir este usuário?');">Excluir</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>

        <!-- Paginação -->
        <nav>
            <ul class="pagination">
                <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                    <li class="page-item <?php echo $i === $page ? 'active' : ''; ?>">
                        <a class="page-link" href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>"><?php echo $i; ?></a>
                    </li>
                <?php endfor; ?>
            </ul>
        </nav>
    </div>

    <!-- Scripts JS (opcionais, para funcionalidades como confirmação de delete, etc) -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>
