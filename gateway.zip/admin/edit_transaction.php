<?php
session_start();

// Verificar se o usuário está autenticado
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login');
    exit;
}

use Dotenv\Dotenv;

require __DIR__ . '/../vendor/autoload.php';

$dotenv = Dotenv::createImmutable(__DIR__ . '/../');
$dotenv->load();

try {
    $dbHost = $_ENV['DB_HOST'];
    $dbnome = $_ENV['DB_NAME'];
    $dbUser = $_ENV['DB_USER'];
    $dbPass = $_ENV['DB_PASS'];

    $dsn = "mysql:host=$dbHost;dbname=$dbnome;charset=utf8";
    $pdo = new PDO($dsn, $dbUser, $dbPass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Erro ao conectar ao banco de dados: " . $e->getMessage());
}

// Verificar se o usuário tem a role 'admin'
$user_id = $_SESSION['user_id'];
$query = "SELECT role FROM users WHERE id = :user_id";
$stmt = $pdo->prepare($query);
$stmt->execute([':user_id' => $user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user || $user['role'] !== 'ADMIN') {
    header('Location: ../login');
    exit;
}

// Obter o ID da transação
if (!isset($_GET['id'])) {
    die("ID da transação não fornecido.");
}

$transaction_id = $_GET['id'];

// Consultar os dados da transação
$query = "SELECT * FROM transactions WHERE id = :id";
$stmt = $pdo->prepare($query);
$stmt->execute([':id' => $transaction_id]);
$transaction = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$transaction) {
    die("Transação não encontrada.");
}

// Atualizar os dados da transação se o formulário for enviado
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update'])) {
        $status = $_POST['status'];
        $descricao = $_POST['descricao'];
        $nome = $_POST['nome'];
        $tax = $_POST['tax'];
        $amount = $_POST['amount'];
        $external_id = $_POST['external_id'];

        $query = "UPDATE transactions 
                  SET status = :status, descricao = :descricao, nome = :nome, tax = :tax, amount = :amount, external_id = :external_id 
                  WHERE id = :id";
        $stmt = $pdo->prepare($query);
        $stmt->execute([
            ':status' => $status,
            ':descricao' => $descricao,
            ':nome' => $nome,
            ':tax' => $tax,
            ':amount' => $amount,
            ':external_id' => $external_id,
            ':id' => $transaction_id
        ]);

        // Atualizar o array da transação para refletir as alterações
        $transaction['status'] = $status;
        $transaction['descricao'] = $descricao;
        $transaction['nome'] = $nome;
        $transaction['tax'] = $tax;
        $transaction['amount'] = $amount;
        $transaction['external_id'] = $external_id;
    }

    if (isset($_POST['cancel'])) {
        $query = "UPDATE transactions SET status = 'CANCELLED' WHERE id = :id";
        $stmt = $pdo->prepare($query);
        $stmt->execute([':id' => $transaction_id]);

        $transaction['status'] = 'CANCELLED';
    }

    if (isset($_POST['approve'])) {
        $query = "UPDATE transactions SET status = 'PAID' WHERE id = :id";
        $stmt = $pdo->prepare($query);
        $stmt->execute([':id' => $transaction_id]);

        $transaction['status'] = 'PAID';
    }

    if (isset($_POST['reverse']) && $transaction['status'] === 'PAID') {
        $query = "UPDATE transactions SET status = 'REVERSED' WHERE id = :id";
        $stmt = $pdo->prepare($query);
        $stmt->execute([':id' => $transaction_id]);

        // Atualizar o saldo do usuário
        $query = "UPDATE users SET balance = balance - :amount WHERE id = :user_id";
        $stmt = $pdo->prepare($query);
        $stmt->execute([':amount' => $transaction['amount'], ':user_id' => $transaction['user_id']]);

        $transaction['status'] = 'REVERSED';
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Transação</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h1>Editar Transação</h1>

        <!-- Botão Voltar -->
        <a href="transaction_list.php" class="btn btn-secondary mb-3">Voltar</a>

        <!-- Formulário de Edição -->
        <form method="POST">
            <div class="form-group">
                <label for="status">Status</label>
                <select name="status" id="status" class="form-control" required>
                    <option value="PENDING" <?php echo $transaction['status'] === 'PENDING' ? 'selected' : ''; ?>>PENDING</option>
                    <option value="PAID" <?php echo $transaction['status'] === 'PAID' ? 'selected' : ''; ?>>PAID</option>
                    <option value="REVERSED" <?php echo $transaction['status'] === 'REVERSED' ? 'selected' : ''; ?>>REVERSED</option>
                    <option value="CANCELLED" <?php echo $transaction['status'] === 'CANCELLED' ? 'selected' : ''; ?>>CANCELLED</option>
                </select>
            </div>
            <div class="form-group">
                <label for="descricao">Descrição</label>
                <input type="text" name="descricao" id="descricao" class="form-control" value="<?php echo htmlspecialchars($transaction['descricao']); ?>">
            </div>
            <div class="form-group">
                <label for="nome">Nome</label>
                <input type="text" name="nome" id="nome" class="form-control" value="<?php echo htmlspecialchars($transaction['nome']); ?>" required>
            </div>
            <div class="form-group">
                <label for="tax">Taxa</label>
                <input type="number" step="0.01" name="tax" id="tax" class="form-control" value="<?php echo htmlspecialchars($transaction['tax']); ?>" required>
            </div>
            <div class="form-group">
                <label for="amount">Valor</label>
                <input type="number" step="0.01" name="amount" id="amount" class="form-control" value="<?php echo htmlspecialchars($transaction['amount']); ?>" required>
            </div>
            <div class="form-group">
                <label for="external_id">External ID</label>
                <input type="text" name="external_id" id="external_id" class="form-control" value="<?php echo htmlspecialchars($transaction['external_id']); ?>" required>
            </div>
            <button type="submit" name="update" class="btn btn-primary">Salvar</button>
        </form>
        
        <!-- Observação -->
        <p class="mt-3 text-muted">Atenção: Altera apenas o status, mas não envia o webhook.</p>

        <!-- Botões de Ação -->
        <div class="mt-3">
            <form method="POST" style="display: inline;">
                <button 
                    type="submit" 
                    name="approve" 
                    class="btn btn-success"
                    <?php echo $transaction['status'] === 'PAID' ? 'disabled' : ''; ?>>
                    Aprovar
                </button>
            </form>

            <form method="POST" style="display: inline;">
                <button 
                    type="submit" 
                    name="reverse" 
                    class="btn btn-warning"
                    <?php echo $transaction['status'] !== 'PAID' ? 'disabled' : ''; ?>>
                    Estornar
                </button>
            </form>
            
            <form method="POST" style="display: inline;">
                <button type="submit" name="delete" class="btn btn-danger">Deletar</button>
            </form>
        </div>
    </div>

    <!-- Scripts JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>
