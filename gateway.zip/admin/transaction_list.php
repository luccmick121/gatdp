<?php
session_start();

// Verificar se o usuário está autenticado
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login'); // Redireciona para a página de login se não estiver autenticado
    exit;
}

use Dotenv\Dotenv;

require __DIR__ . '/../vendor/autoload.php';

$dotenv = Dotenv::createImmutable(__DIR__ . '/../');
$dotenv->load();

try {
    $dbHost = $_ENV['DB_HOST'];
    $dbName = $_ENV['DB_NAME'];
    $dbUser = $_ENV['DB_USER'];
    $dbPass = $_ENV['DB_PASS'];

    $dsn = "mysql:host=$dbHost;dbname=$dbName;charset=utf8";
    $pdo = new PDO($dsn, $dbUser, $dbPass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Erro ao conectar ao banco de dados: " . $e->getMessage());
}

// Consultar o role do usuário com base no user_id da sessão
$user_id = $_SESSION['user_id'];
$query = "SELECT id, username, email, role FROM users WHERE id = :user_id";
$stmt = $pdo->prepare($query);
$stmt->execute([':user_id' => $user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// Verificar se o usuário existe no banco
if (!$user) {
    header('Location: ../login'); // Redireciona para o login se o usuário não for encontrado
    exit;
}

// Verificar se o usuário tem a role 'admin'
if ($user['role'] !== 'ADMIN') {
    header('Location: ../login'); // Redireciona para o login se não for admin
    exit;
}

// Configuração de limite e paginação
$limit = 10; // Número de registros por página
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1; // Página atual
$offset = ($page - 1) * $limit; // Calcular o offset

// Verificar se há uma busca por nome de usuário
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

// Consulta SQL com JOIN para buscar transações e incluir os nomes de usuário
$query = "SELECT t.id, t.user_id, t.amount, t.type, t.status, t.created_at, u.username 
          FROM transactions t 
          INNER JOIN users u ON t.user_id = u.id";

// Adicionar filtro de busca, caso exista
if (!empty($search)) {
    $query .= " WHERE u.username LIKE :search";
}

$query .= " LIMIT :limit OFFSET :offset";

$stmt = $pdo->prepare($query);

// Bind dos parâmetros
if (!empty($search)) {
    $stmt->bindValue(':search', '%' . $search . '%', PDO::PARAM_STR);
}
$stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();

$transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Consultar o número total de registros (para paginação)
$totalQuery = "SELECT COUNT(*) 
               FROM transactions t 
               INNER JOIN users u ON t.user_id = u.id";

if (!empty($search)) {
    $totalQuery .= " WHERE u.username LIKE :search";
}

$totalStmt = $pdo->prepare($totalQuery);

// Bind do parâmetro de busca, caso exista
if (!empty($search)) {
    $totalStmt->bindValue(':search', '%' . $search . '%', PDO::PARAM_STR);
}
$totalStmt->execute();
$totalTransactions = $totalStmt->fetchColumn();
$totalPages = ceil($totalTransactions / $limit); // Total de páginas
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Lista de Transações</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h1>Lista de Transações</h1>

        <!-- Formulário de busca -->
        <form method="get" class="mb-4">
            <div class="input-group">
                <input type="text" name="search" class="form-control" placeholder="Buscar por usuário" value="<?php echo htmlspecialchars($search); ?>">
                <div class="input-group-append">
                    <button class="btn btn-primary" type="submit">Buscar</button>
                </div>
            </div>
        </form>

        <!-- Menu de Navegação -->
        <?php
        // Assumindo que a conexão com o banco de dados já foi realizada anteriormente

        // Consultar o número de documentos com approved = 0
        $query = "SELECT COUNT(*) AS pending_documents FROM users_documents WHERE approved = 0";
        $stmt = $pdo->prepare($query);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        // Obter o número de documentos pendentes
        $pending_documents = $result['pending_documents'];
        ?>

        <div class="mb-3">
            <a href="user_list.php" class="btn btn-secondary">Usuários</a>
            <a href="transaction_list.php" class="btn btn-primary">Transações</a>
            <a href="documents_list" class="btn btn-secondary">
                Documentos
                <?php if ($pending_documents > 0): ?>
                    <span class="badge badge-danger ml-2"><?php echo $pending_documents; ?></span>
                <?php endif; ?>
            </a>
            <a href="config_edit.php" class="btn btn-secondary">Configurações do Site</a>
        </div>

        <a href="../" class="btn btn-danger mb-3">Sair</a>

        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Usuário</th>
                    <th>Valor</th>
                    <th>Tipo</th>
                    <th>Status</th>
                    <th>Data</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($transactions as $transaction): ?>
                    <tr>
                        <td><?php echo $transaction['id']; ?></td>
                        <td><?php echo htmlspecialchars($transaction['username']); ?></td>
                        <td><?php echo htmlspecialchars($transaction['amount']); ?></td>
                        <td><?php echo htmlspecialchars($transaction['type']); ?></td>
                        <td><?php echo htmlspecialchars($transaction['status']); ?></td>
                        <td><?php echo htmlspecialchars($transaction['created_at']); ?></td>
                        <td>
                            <a href="edit_transaction.php?id=<?php echo $transaction['id']; ?>" class="btn btn-warning btn-sm">Editar</a>
                            <a href="delete_transaction.php?id=<?php echo $transaction['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Tem certeza que deseja excluir esta transação?');">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <!-- Paginação -->
        <nav>
            <ul class="pagination">
                <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                    <li class="page-item <?php echo $i === $page ? 'active' : ''; ?>">
                        <a class="page-link" href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>"><?php echo $i; ?></a>
                    </li>
                <?php endfor; ?>
            </ul>
        </nav>
    </div>

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>
