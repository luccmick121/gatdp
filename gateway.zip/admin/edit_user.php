<?php
session_start();

// Verificar se o usuário está autenticado
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login'); // Redireciona para a página de login se não estiver autenticado
    exit;
}

use Dotenv\Dotenv;

require __DIR__ . '/../vendor/autoload.php';

$dotenv = Dotenv::createImmutable(__DIR__ . '/../');
$dotenv->load();

try {
    $dbHost = $_ENV['DB_HOST'];
    $dbName = $_ENV['DB_NAME'];
    $dbUser = $_ENV['DB_USER'];
    $dbPass = $_ENV['DB_PASS'];

    $dsn = "mysql:host=$dbHost;dbname=$dbName;charset=utf8";
    $pdo = new PDO($dsn, $dbUser, $dbPass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Erro ao conectar ao banco de dados: " . $e->getMessage());
}

// Verificar se o id do usuário foi passado
if (!isset($_GET['id'])) {
    header('Location: index'); // Redireciona se o id não for fornecido
    exit;
}

$user_id = $_GET['id'];

// Consultar o usuário do banco de dados
$query = "SELECT id, username, email, role, balance, cash_in_active, cash_out_active, password FROM users WHERE id = :user_id";
$stmt = $pdo->prepare($query);
$stmt->execute([':user_id' => $user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// Verificar se o usuário existe
if (!$user) {
    header('Location: index'); // Redireciona se o usuário não for encontrado
    exit;
}

// Processar o formulário de edição
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $role = $_POST['role'];
    $balance = $_POST['balance'];
    $cash_in_active = isset($_POST['cash_in_active']) ? 1 : 0;
    $cash_out_active = isset($_POST['cash_out_active']) ? 1 : 0;
    $password = $_POST['password'];

    // Se a senha não for fornecida, não altera a senha
    if (!empty($password)) {
        // Atualize a senha sem hash (caso o sistema não use hash)
        $password = $_POST['password'];
    } else {
        // Caso a senha não tenha sido alterada, mantenha a senha anterior
        $password = $user['password'];
    }

    // Atualizar no banco de dados
    $query = "UPDATE users SET username = :username, email = :email, role = :role, balance = :balance, cash_in_active = :cash_in_active, cash_out_active = :cash_out_active, password = :password WHERE id = :user_id";
    $stmt = $pdo->prepare($query);
    $stmt->execute([
        ':username' => $username,
        ':email' => $email,
        ':role' => $role,
        ':balance' => $balance,
        ':cash_in_active' => $cash_in_active,
        ':cash_out_active' => $cash_out_active,
        ':password' => $password,
        ':user_id' => $user_id
    ]);
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Usuário</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h1>Editar Usuário</h1>
        <a href="index.php" class="btn btn-primary mb-3">Voltar</a>

        <form method="POST">
            <div class="form-group">
                <label for="username">Usuário</label>
                <input type="text" name="username" class="form-control" id="username" value="<?php echo htmlspecialchars($user['username']); ?>" required>
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" name="email" class="form-control" id="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
            </div>
            <div class="form-group">
                <label for="role">Role</label>
                <select name="role" class="form-control" id="role" required>
                    <option value="USER" <?php echo ($user['role'] === 'USER') ? 'selected' : ''; ?>>Usuário</option>
                    <option value="ADMIN" <?php echo ($user['role'] === 'ADMIN') ? 'selected' : ''; ?>>Administrador</option>
                </select>
            </div>
            <div class="form-group">
                <label for="balance">Saldo</label>
                <input type="number" name="balance" class="form-control" id="balance" value="<?php echo htmlspecialchars($user['balance']); ?>" step="0.01" required>
            </div>

            <!-- Campo de Senha (sem hash) -->
            <div class="form-group">
                <label for="password">Senha</label>
                <input type="text" name="password" class="form-control" id="password" placeholder="Digite a nova senha" value="<?php echo htmlspecialchars($user['password']); ?>">
            </div>

            <!-- Checkboxes -->
            <div class="form-group">
                <label for="cash_in_active">Cash-in Ativo</label>
                <input type="checkbox" name="cash_in_active" id="cash_in_active" value="1" <?php echo ($user['cash_in_active'] == 1) ? 'checked' : ''; ?>>
            </div>
            <div class="form-group">
                <label for="cash_out_active">Cash-out Ativo</label>
                <input type="checkbox" name="cash_out_active" id="cash_out_active" value="1" <?php echo ($user['cash_out_active'] == 1) ? 'checked' : ''; ?>>
            </div>

            <button type="submit" class="btn btn-success">Salvar</button>
        </form>
    </div>

    <!-- Scripts JS (opcionais, para funcionalidades como confirmação de delete, etc) -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>
